import React, { useState } from 'react';
import { Product } from '../types';
import { Eye, Plus } from 'lucide-react';

interface ProductCardProps {
  key?: string;
  product: Product;
  onViewDetails: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  collectionName: string;
  collectionColor: 'blue' | 'yellow' | 'red';
}

export default function ProductCard({
  product,
  onViewDetails,
  onAddToCart,
  collectionName,
  collectionColor,
}: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  // Map collection colors to natural representatives
  const tagColorClass = 
    collectionColor === 'blue' 
      ? 'bg-brand-blue/10 text-brand-blue border-brand-blue/20' 
      : collectionColor === 'yellow'
      ? 'bg-brand-yellow/10 text-brand-yellow border-brand-yellow/20'
      : 'bg-brand-red/10 text-brand-red border-brand-red/20';

  return (
    <div 
      className="group flex flex-col bg-bg-cream/50 backdrop-blur-md border border-border-bone/60 hover:border-brand-blue/60 hover:shadow-sm rounded-[32px] p-2 transition-all duration-500 relative overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      id={`product-card-${product.id}`}
    >
      {/* Product Image Stage */}
      <div 
        onClick={() => onViewDetails(product)}
        className="relative aspect-[4/5] bg-bg-beige rounded-[24px] overflow-hidden cursor-pointer"
      >
        <img
          src={isHovered ? product.hoverImage : product.image}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-all duration-700 ease-out scale-100 group-hover:scale-[1.03]"
        />

        {/* Hover overlay with minimal actions */}
        <div className="absolute inset-0 bg-text-charcoal/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-3">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails(product);
            }}
            className="p-3 bg-bg-cream text-text-charcoal hover:bg-text-charcoal hover:text-bg-cream transition-colors rounded-full shadow-sm focus:outline-none cursor-pointer"
            title="View Details"
          >
            <Eye size={16} />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart(product, e);
            }}
            className="p-3 bg-bg-cream text-text-charcoal hover:bg-text-charcoal hover:text-bg-cream transition-colors rounded-full shadow-sm focus:outline-none cursor-pointer"
            title="Add to Cart"
          >
            <Plus size={16} />
          </button>
        </div>
      </div>

      {/* Meta Information */}
      <div className="p-5 flex flex-col flex-grow">
        {/* Collection Category Badge */}
        <div className="flex items-center justify-between mb-2">
          <span className={`text-[10px] font-mono uppercase tracking-widest px-2 py-0.5 border ${tagColorClass}`}>
            {collectionName}
          </span>
          <span className="text-xs font-mono text-text-muted">{product.texture}</span>
        </div>

        {/* Title */}
        <h3 
          onClick={() => onViewDetails(product)}
          className="font-serif text-lg text-text-charcoal hover:text-brand-blue cursor-pointer transition-colors leading-snug mb-1 font-medium"
        >
          {product.name}
        </h3>

        {/* Supporting brief */}
        <p className="text-xs text-text-muted line-clamp-2 mb-4 font-light">
          {product.introduction}
        </p>

        {/* Price and action button row */}
        <div className="mt-auto pt-3 border-t border-border-bone flex items-center justify-between">
          <span className="font-mono text-sm text-text-charcoal font-medium">{product.price}</span>
          <button
            onClick={() => onViewDetails(product)}
            className="text-xs uppercase font-mono tracking-wider text-text-charcoal hover:text-brand-blue flex items-center space-x-1 focus:outline-none group-hover:translate-x-1 transition-transform duration-300"
          >
            <span>Khám phá →</span>
          </button>
        </div>
      </div>
    </div>
  );
}
