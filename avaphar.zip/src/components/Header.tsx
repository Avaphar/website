import { ShoppingBag, Menu, X, Compass } from 'lucide-react';
import { CartItem } from '../types';

interface HeaderProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  selectedCollectionId: string | null;
  onSelectCollection: (id: string | null) => void;
  cart: CartItem[];
  onOpenCart: () => void;
  menuOpen: boolean;
  setMenuOpen: (open: boolean) => void;
}

export default function Header({
  currentPage,
  onPageChange,
  onSelectCollection,
  cart,
  onOpenCart,
  menuOpen,
  setMenuOpen,
}: HeaderProps) {
  const totalCartItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  const navItems = [
    { id: 'home', label: 'Trang chủ' },
    { id: 'about', label: 'Giới thiệu' },
    { id: 'collections', label: 'Bộ sưu tập' },
    { id: 'ingredients', label: 'Thành phần' },
    { id: 'journal', label: 'Ký sự' },
    { id: 'contact', label: 'Liên hệ' },
  ];

  const handleNavClick = (pageId: string) => {
    onPageChange(pageId);
    if (pageId !== 'collections') {
      onSelectCollection(null);
    }
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-bg-cream/90 backdrop-blur-md border-b border-border-bone transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-24 flex items-center justify-between relative">
          
          {/* Left: Brand Logo and Hamburger/Info */}
          <div className="flex items-center space-x-4 z-10">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="lg:hidden p-2 text-text-charcoal hover:text-brand-blue transition-colors -ml-2"
              aria-label="Toggle menu"
            >
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>

            {/* Sacred Geometry Brand Logo with Original Colors */}
            <button 
              onClick={() => handleNavClick('home')}
              className="group focus:outline-none"
              aria-label="Home"
            >
              <svg viewBox="0 0 100 100" className="w-10 h-10 shrink-0 transition-transform duration-300 group-hover:scale-105" aria-hidden="true">
                {/* Yellow circles in the corners */}
                <circle cx="15" cy="15" r="7.5" fill="#FAB818" />
                <circle cx="85" cy="15" r="7.5" fill="#FAB818" />
                <circle cx="15" cy="85" r="7.5" fill="#FAB818" />
                <circle cx="85" cy="85" r="7.5" fill="#FAB818" />
                {/* Vertical Blue Pills */}
                <rect x="29" y="10" width="14" height="38" rx="7" fill="#154295" />
                <rect x="57" y="52" width="14" height="38" rx="7" fill="#154295" />
                {/* Horizontal Red Pills */}
                <rect x="52" y="29" width="38" height="14" rx="7" fill="#B30E16" />
                <rect x="10" y="57" width="38" height="14" rx="7" fill="#B30E16" />
              </svg>
            </button>
            
            <div className="hidden lg:flex items-center space-x-2 text-xs font-mono uppercase tracking-wider text-text-muted">
              <span className="opacity-85">Est. 2026 · Avaphar Slow Beauty</span>
            </div>
          </div>

          {/* Center: Brand Wordmark absolutely centered */}
          <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 flex items-center justify-center z-0 pointer-events-none">
            <button 
              onClick={() => handleNavClick('home')}
              className="group flex flex-col items-center focus:outline-none pointer-events-auto"
            >
              <span className="font-serif text-2xl sm:text-3xl font-light tracking-[0.25em] text-text-charcoal group-hover:text-brand-blue transition-colors duration-300 leading-none">
                AVAPHAR
              </span>
              <span className="text-[9px] font-mono uppercase tracking-[0.4em] text-text-muted mt-1.5 pl-0.5 leading-none">
                Vietnam
              </span>
            </button>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center space-x-3 sm:space-x-6">
            <nav className="hidden lg:flex space-x-8">
              {navItems.map((item) => {
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`relative text-xs uppercase font-mono tracking-wider transition-colors py-2 focus:outline-none cursor-pointer ${
                      isActive ? 'text-text-charcoal font-medium' : 'text-text-muted hover:text-text-charcoal'
                    }`}
                  >
                    {item.label}
                    {isActive && (
                      <span className="absolute bottom-0 left-0 w-full h-[1px] bg-brand-blue animate-fade-in"></span>
                    )}
                  </button>
                );
              })}
            </nav>

            <div className="w-[1px] h-4 bg-border-bone hidden lg:block"></div>

            {/* Cart Trigger */}
            <button
              onClick={onOpenCart}
              className="relative p-2.5 rounded-full hover:bg-bg-beige transition-colors duration-200 group focus:outline-none"
              aria-label="Open cart"
            >
              <ShoppingBag size={18} className="text-text-charcoal group-hover:text-brand-blue transition-colors" />
              {totalCartItems > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-brand-red text-bg-cream text-[10px] font-mono font-medium rounded-full w-5 h-5 flex items-center justify-center border-2 border-bg-cream">
                  {totalCartItems}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {menuOpen && (
        <div className="fixed inset-0 top-24 z-30 bg-bg-cream lg:hidden animate-fade-in flex flex-col justify-between p-8 border-t border-border-bone">
          <div className="space-y-6">
            <span className="text-xs font-mono uppercase tracking-widest text-text-muted block border-b border-border-bone pb-2">
              Danh mục Điều hướng
            </span>
            <div className="flex flex-col space-y-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className="text-left font-serif text-3xl font-light text-text-charcoal hover:text-brand-blue transition-colors py-1"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-border-bone pt-6 space-y-4">
            <div className="flex items-center space-x-3 text-xs font-mono text-text-muted">
              <Compass size={14} />
              <span>120 Organic Earth Way, Botanical Hills</span>
            </div>
            <div className="text-xs font-mono text-text-muted">
              info@avaphar-botanical.com
            </div>
            <div className="flex space-x-4 text-xs font-mono text-text-muted">
              <span className="text-brand-blue font-medium">● Xanh Thủy Triều</span>
              <span className="text-brand-yellow font-medium">● Vàng Phấn Hoa</span>
              <span className="text-brand-red font-medium">● Đỏ Đất Nung</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
