import React, { useState } from 'react';
import { Leaf, Mail, Compass, HelpCircle } from 'lucide-react';

interface FooterProps {
  onPageChange: (page: string) => void;
  onSelectCollection: (id: string | null) => void;
}

export default function Footer({ onPageChange, onSelectCollection }: FooterProps) {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim() && email.includes('@')) {
      setSubscribed(true);
      setEmail('');
    }
  };

  const handleLinkClick = (pageId: string, collectionId: string | null = null) => {
    onPageChange(pageId);
    onSelectCollection(collectionId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-bg-beige border-t border-border-bone mt-24">
      {/* Newsletter Block: Sits inside a Soft Beige full-width band */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 border-b border-border-bone/80">
        <div className="max-w-2xl mx-auto text-center space-y-6">
          <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-brand-yellow font-medium block">
            The Journal Dispatch
          </span>
          <h3 className="font-serif text-3xl font-light text-text-charcoal tracking-wide leading-tight">
            Subscribe to our seasonal chronicles of earth & beauty
          </h3>
          <p className="text-xs text-text-muted font-light max-w-md mx-auto leading-relaxed">
            Unsubscribe anytime. We send botanical findings, craftsmanship essays, and occasional early harvesting collection launches.
          </p>

          {subscribed ? (
            <div className="p-4 bg-brand-blue/5 border border-brand-blue/20 text-brand-blue text-xs font-mono uppercase tracking-wider animate-fade-in inline-block rounded">
              Welcome to the Journal. Sensory invitation dispatched.
            </div>
          ) : (
            <form onSubmit={handleSubscribe} className="max-w-md mx-auto flex flex-col sm:flex-row items-stretch space-y-3 sm:space-y-0 sm:space-x-3 pt-2">
              <div className="relative flex-grow">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="sterling@slowbeauty.com"
                  required
                  className="w-full bg-transparent border-b border-text-muted/40 py-3 px-1 text-sm text-text-charcoal placeholder:text-text-muted/45 focus:outline-none focus:border-brand-blue transition-colors font-sans"
                />
              </div>
              <button
                type="submit"
                className="py-3 px-8 bg-brand-blue hover:bg-brand-blue-light text-bg-cream text-xs font-mono uppercase tracking-widest rounded-full transition-all duration-300"
              >
                Subscribe
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Main Footer Column Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8">
          
          {/* Column 1: Brand intro */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center space-x-3.5">
              <svg viewBox="0 0 100 100" className="w-11 h-11 shrink-0" aria-hidden="true">
                {/* Yellow circles in the corners */}
                <circle cx="15" cy="15" r="7.5" fill="#FAB818" />
                <circle cx="85" cy="15" r="7.5" fill="#FAB818" />
                <circle cx="15" cy="85" r="7.5" fill="#FAB818" />
                <circle cx="85" cy="85" r="7.5" fill="#FAB818" />
                {/* Vertical Blue Pills */}
                <rect x="29" y="10" width="14" height="38" rx="7" fill="#154295" />
                <rect x="57" y="52" width="14" height="38" rx="7" fill="#154295" />
                {/* Horizontal Red Pills */}
                <rect x="52" y="29" width="38" height="14" rx="7" fill="#B30E16" />
                <rect x="10" y="57" width="38" height="14" rx="7" fill="#B30E16" />
              </svg>
              <div className="flex flex-col">
                <span className="font-serif text-2xl font-light tracking-[0.25em] text-text-charcoal">
                  AVAPHAR
                </span>
                <span className="text-[9px] font-mono uppercase tracking-[0.4em] text-text-muted -mt-0.5 pl-1">
                  Vietnam
                </span>
              </div>
            </div>
            
            <p className="text-xs text-text-muted font-light leading-relaxed max-w-sm">
              We translate natural color codes into physical, restorative botanical specimens. Blue (Water Bio-actives), Yellow (Warm Honey Solar resins), and Red (Clay Earth silts). Grounded in raw science and absolute, uncompromised honesty.
            </p>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs font-mono text-text-muted">
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-brand-blue"></span>
                <span>Xanh Thủy Triều (Water)</span>
              </span>
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-brand-yellow"></span>
                <span>Vàng Phấn Hoa (Sun)</span>
              </span>
              <span className="flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-brand-red"></span>
                <span>Đỏ Đất Nung (Earth)</span>
              </span>
            </div>
          </div>

          {/* Column 2: Shop links */}
          <div className="space-y-4">
            <h4 className="text-[11px] font-mono uppercase tracking-widest text-text-charcoal font-medium">
              Earthy Series
            </h4>
            <ul className="space-y-2 text-xs font-light text-text-muted">
              <li>
                <button 
                  onClick={() => handleLinkClick('collections', 'metabi')}
                  className="hover:text-brand-blue hover:underline text-left cursor-pointer transition-all focus:outline-none"
                >
                  METABI Marine (Blue)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleLinkClick('collections', 'candles')}
                  className="hover:text-brand-yellow hover:underline text-left cursor-pointer transition-all focus:outline-none"
                >
                  Solar Honey (Yellow)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleLinkClick('collections', 'soaps')}
                  className="hover:text-brand-red hover:underline text-left cursor-pointer transition-all focus:outline-none"
                >
                  Terracotta Clay (Red)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleLinkClick('collections')}
                  className="hover:text-text-charcoal hover:underline text-left cursor-pointer transition-all focus:outline-none"
                >
                  All Collections Overview
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Explore links */}
          <div className="space-y-4">
            <h4 className="text-[11px] font-mono uppercase tracking-widest text-text-charcoal font-medium">
              Explore
            </h4>
            <ul className="space-y-2 text-xs font-light text-text-muted">
              <li>
                <button 
                  onClick={() => handleLinkClick('about')}
                  className="hover:text-text-charcoal hover:underline text-left cursor-pointer transition-all focus:outline-none"
                >
                  Our Soil-to-Skin Philosophy
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleLinkClick('ingredients')}
                  className="hover:text-text-charcoal hover:underline text-left cursor-pointer transition-all focus:outline-none"
                >
                  Botanical Ingredient Library
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleLinkClick('journal')}
                  className="hover:text-text-charcoal hover:underline text-left cursor-pointer transition-all focus:outline-none"
                >
                  The Journal (Slow Chronicles)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => handleLinkClick('contact')}
                  className="hover:text-text-charcoal hover:underline text-left cursor-pointer transition-all focus:outline-none"
                >
                  Studio Location & Hours
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact & Social */}
          <div className="space-y-4">
            <h4 className="text-[11px] font-mono uppercase tracking-widest text-text-charcoal font-medium">
              Information
            </h4>
            <ul className="space-y-2 text-xs font-light text-text-muted leading-relaxed">
              <li className="flex items-start space-x-2">
                <Compass size={14} className="shrink-0 text-text-muted mt-0.5" />
                <span>120 Organic Earth Way, Botanical Hills, NY</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail size={14} className="shrink-0 text-text-muted" />
                <span>info@avaphar-botanical.com</span>
              </li>
              <li className="pt-2">
                <div className="flex space-x-4 text-xs font-mono uppercase tracking-wider text-text-muted">
                  <a href="#instagram" className="hover:text-text-charcoal hover:underline">Instagram</a>
                  <a href="#pinterest" className="hover:text-text-charcoal hover:underline">Pinterest</a>
                </div>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border-bone/80 mt-16 pt-8 flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0 text-[11px] font-mono text-text-muted">
          <div>
            © 2026 AVAPHAR Ltd. Cold-Pressed Integrity. All Rights Reserved.
          </div>
          <div className="flex space-x-6">
            <a href="#privacy" className="hover:text-text-charcoal">Privacy Principles</a>
            <a href="#terms" className="hover:text-text-charcoal">Ethical Terms</a>
            <span className="text-text-muted/60">Currency: USD ($)</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
