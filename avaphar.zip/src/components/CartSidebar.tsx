import React, { useState } from 'react';
import { CartItem, Product } from '../types';
import { X, Plus, Minus, Trash2, Check, Sparkles, AlertCircle } from 'lucide-react';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

type CheckoutStep = 'cart' | 'details' | 'success';

export default function CartSidebar({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartSidebarProps) {
  const [step, setStep] = useState<CheckoutStep>('cart');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [wrapOption, setWrapOption] = useState('eucalyptus'); // eucalyptus | lavender | oatpaper
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  if (!isOpen) return null;

  // Calculate Subtotal
  const subtotal = cart.reduce((acc, item) => {
    const priceNum = parseFloat(item.product.price.replace('$', ''));
    return acc + priceNum * item.quantity;
  }, 0);

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { [key: string]: string } = {};
    if (!name.trim()) newErrors.name = 'Vui lòng nhập họ và tên của bạn';
    if (!email.trim() || !email.includes('@')) newErrors.email = 'Vui lòng nhập địa chỉ email hợp lệ';
    if (!address.trim()) newErrors.address = 'Vui lòng nhập địa chỉ giao hàng của bạn';
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setStep('success');
  };

  const handleClose = () => {
    onClose();
    // Reset steps when closed
    setTimeout(() => {
      setStep('cart');
      setName('');
      setEmail('');
      setAddress('');
      setWrapOption('eucalyptus');
    }, 300);
  };

  const handleSuccessClose = () => {
    onClearCart();
    handleClose();
  };

  const wrapDetails = {
    eucalyptus: {
      title: 'Lá khuynh diệp phân hủy sinh học',
      desc: 'Cành cây thô mộc buộc bằng dây gai hữu cơ. Mang lại hương thơm ngút ngàn của rừng thông ngay khi mở hộp.',
      color: 'border-brand-blue/30 text-brand-blue bg-brand-blue/5',
    },
    lavender: {
      title: 'Nhành oải hương núi sấy khô',
      desc: 'Được thắt ruy-băng vải lanh tự nhiên. Đi kèm một túi thơm trị liệu nhỏ giúp thư giãn tâm hồn.',
      color: 'border-brand-red/30 text-brand-red bg-brand-red/5',
    },
    oatpaper: {
      title: 'Giấy yến mạch tái chế ép mặt trời',
      desc: 'Được ép bằng ánh sáng mặt trời cùng vỏ yến mạch thật. Bao bì phân hủy sinh học hoàn toàn trong vườn nhà.',
      color: 'border-brand-yellow/30 text-brand-yellow bg-brand-yellow/5',
    },
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" aria-labelledby="slide-over-title" role="dialog" aria-modal="true">
      <div className="absolute inset-0 overflow-hidden">
        {/* Backdrop overlay */}
        <div 
          className="absolute inset-0 bg-text-charcoal/40 backdrop-blur-sm transition-opacity" 
          onClick={step === 'success' ? handleSuccessClose : handleClose}
        ></div>

        <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
          <div className="pointer-events-auto w-screen max-w-md">
            <div className="flex h-full flex-col bg-bg-cream shadow-2xl border-l border-border-bone animate-fade-in">
              
              {/* Sidebar Header */}
              <div className="px-6 py-6 border-b border-border-bone flex items-center justify-between bg-bg-beige/40">
                <h2 className="text-sm font-mono uppercase tracking-wider text-text-charcoal flex items-center space-x-2">
                  <span>Giỏ Thảo Mộc</span>
                  <span className="text-xs text-text-muted">({cart.reduce((a, b) => a + b.quantity, 0)})</span>
                </h2>
                <button
                  onClick={step === 'success' ? handleSuccessClose : handleClose}
                  className="p-1 rounded-full text-text-muted hover:text-text-charcoal hover:bg-bg-beige transition-all"
                >
                  <X size={18} />
                </button>
              </div>

              {/* Sidebar Scrollable Body */}
              <div className="flex-1 overflow-y-auto px-6 py-6">
                
                {step === 'cart' && (
                  <>
                    {cart.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center px-4">
                        <div className="w-16 h-16 rounded-full bg-bg-beige flex items-center justify-center mb-4 text-text-muted">
                          <Sparkles size={24} className="animate-pulse" />
                        </div>
                        <h3 className="font-serif text-lg font-medium text-text-charcoal mb-1">Giỏ của bạn đang trống</h3>
                        <p className="text-xs text-text-muted font-light max-w-xs mb-6">
                          Các dòng sản phẩm chăm sóc cá nhân tự nhiên, bền vững của chúng tôi đang chờ để làm phong phú thêm nghi thức tự chăm sóc hàng ngày của bạn.
                        </p>
                        <button
                          onClick={handleClose}
                          className="px-6 py-3 bg-brand-blue hover:bg-brand-blue-light text-bg-cream text-xs font-mono uppercase tracking-wider transition-colors duration-300"
                        >
                          Quay lại Danh mục Thảo mộc
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-6">
                        {cart.map((item) => (
                          <div 
                            key={item.product.id} 
                            className="flex items-start space-x-4 border-b border-border-bone pb-6 last:border-b-0"
                          >
                            <img
                              src={item.product.image}
                              alt={item.product.name}
                              referrerPolicy="no-referrer"
                              className="w-20 h-24 object-cover bg-bg-beige border border-border-bone/40"
                            />
                            <div className="flex-grow flex flex-col">
                              <h4 className="font-serif text-sm font-medium text-text-charcoal leading-tight">
                                {item.product.name}
                              </h4>
                              <span className="text-[10px] font-mono text-text-muted uppercase tracking-wider mt-1">
                                {item.product.texture}
                              </span>
                              <span className="font-mono text-xs text-text-charcoal mt-2 font-semibold">
                                {item.product.price}
                              </span>

                              {/* Item Quantity control */}
                              <div className="flex items-center justify-between mt-3">
                                <div className="flex items-center border border-border-bone bg-bg-cream rounded">
                                  <button
                                    onClick={() => onUpdateQuantity(item.product.id, Math.max(1, item.quantity - 1))}
                                    className="p-1 px-2 text-text-muted hover:text-text-charcoal transition-colors focus:outline-none"
                                  >
                                    <Minus size={12} />
                                  </button>
                                  <span className="px-2 font-mono text-xs text-text-charcoal">{item.quantity}</span>
                                  <button
                                    onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                                    className="p-1 px-2 text-text-muted hover:text-text-charcoal transition-colors focus:outline-none"
                                  >
                                    <Plus size={12} />
                                  </button>
                                </div>

                                <button
                                  onClick={() => onRemoveItem(item.product.id)}
                                  className="text-text-muted hover:text-brand-red flex items-center space-x-1 text-xs font-mono transition-colors focus:outline-none"
                                >
                                  <Trash2 size={12} />
                                  <span>Xóa</span>
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </>
                )}

                 {step === 'details' && (
                  <form onSubmit={handleCheckoutSubmit} className="space-y-6 animate-fade-in">
                    <div>
                      <h3 className="font-serif text-lg font-medium text-text-charcoal mb-1">Địa chỉ Giao nhận Nghi thức</h3>
                      <p className="text-xs text-text-muted font-light">
                        Chúng tôi đóng gói tất cả sản phẩm bằng các nguyên tố hữu cơ thô mộc. Vui lòng nhập thông tin giao nhận bên dưới.
                      </p>
                    </div>

                    <div className="space-y-4">
                      {/* Name */}
                      <div>
                        <label className="block text-[11px] font-mono uppercase tracking-wider text-text-muted mb-1.5">
                          Tên người nhận
                        </label>
                        <input
                          type="text"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className={`w-full bg-transparent border-b ${
                            errors.name ? 'border-brand-red' : 'border-border-bone'
                          } py-2 text-sm text-text-charcoal placeholder:text-text-muted/50 focus:outline-none focus:border-brand-blue transition-colors`}
                          placeholder="ví dụ: Evelyn Sterling"
                        />
                        {errors.name && (
                          <p className="text-xs text-brand-red mt-1 font-mono flex items-center space-x-1">
                            <AlertCircle size={10} />
                            <span>{errors.name}</span>
                          </p>
                        )}
                      </div>

                      {/* Email */}
                      <div>
                        <label className="block text-[11px] font-mono uppercase tracking-wider text-text-muted mb-1.5">
                          Email (Để nhận Biên lai Cảm quan)
                        </label>
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className={`w-full bg-transparent border-b ${
                            errors.email ? 'border-brand-red' : 'border-border-bone'
                          } py-2 text-sm text-text-charcoal placeholder:text-text-muted/50 focus:outline-none focus:border-brand-blue transition-colors`}
                          placeholder="sterling@slowbeauty.com"
                        />
                        {errors.email && (
                          <p className="text-xs text-brand-red mt-1 font-mono flex items-center space-x-1">
                            <AlertCircle size={10} />
                            <span>{errors.email}</span>
                          </p>
                        )}
                      </div>

                      {/* Address */}
                      <div>
                        <label className="block text-[11px] font-mono uppercase tracking-wider text-text-muted mb-1.5">
                          Địa chỉ Giao hàng Đầy đủ
                        </label>
                        <input
                          type="text"
                          value={address}
                          onChange={(e) => setAddress(e.target.value)}
                          className={`w-full bg-transparent border-b ${
                            errors.address ? 'border-brand-red' : 'border-border-bone'
                          } py-2 text-sm text-text-charcoal placeholder:text-text-muted/50 focus:outline-none focus:border-brand-blue transition-colors`}
                          placeholder="120 Organic Earth Way, Botanical Hills, NY"
                        />
                        {errors.address && (
                          <p className="text-xs text-brand-red mt-1 font-mono flex items-center space-x-1">
                            <AlertCircle size={10} />
                            <span>{errors.address}</span>
                          </p>
                        )}
                      </div>

                      {/* Botanical Gift Wrapping Selector */}
                      <div className="pt-4">
                        <label className="block text-[11px] font-mono uppercase tracking-wider text-text-muted mb-3">
                          Chọn Hình thức Đóng gói Hữu cơ (Miễn phí)
                        </label>
                        <div className="space-y-3">
                          {Object.entries(wrapDetails).map(([key, detail]) => (
                            <label
                              key={key}
                              className={`flex flex-col p-4 border cursor-pointer transition-all ${
                                wrapOption === key 
                                  ? `${detail.color} border-2` 
                                  : 'border-border-bone hover:border-text-muted bg-transparent'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-mono font-medium uppercase tracking-wider">
                                  {detail.title}
                                </span>
                                <input
                                  type="radio"
                                  name="wrapOption"
                                  value={key}
                                  checked={wrapOption === key}
                                  onChange={() => setWrapOption(key)}
                                  className="sr-only"
                                />
                                {wrapOption === key && <Check size={14} className="text-text-charcoal" />}
                              </div>
                              <span className="text-xs text-text-muted mt-1.5 font-light leading-relaxed">
                                {detail.desc}
                              </span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </div>
                  </form>
                )}

                 {step === 'success' && (
                  <div className="h-full flex flex-col items-center justify-center text-center px-4 animate-fade-in">
                    <div className="w-16 h-16 rounded-full bg-brand-blue/10 flex items-center justify-center mb-6 text-brand-blue">
                      <Check size={28} />
                    </div>
                    <span className="text-[10px] font-mono uppercase tracking-widest text-brand-blue bg-brand-blue/10 px-2.5 py-1 border border-brand-blue/20 mb-4">
                      Yêu cầu Đặt hàng Đã Xác nhận
                    </span>
                    <h3 className="font-serif text-2xl font-light text-text-charcoal leading-snug mb-3">
                      Nghi Thức Thảo Mộc Của Bạn Đã Sẵn Sàng
                    </h3>
                    
                    <div className="bg-bg-beige/40 border border-border-bone/80 p-5 rounded-lg w-full text-left mb-6 space-y-3">
                      <p className="text-xs font-mono text-text-muted border-b border-border-bone pb-2 uppercase tracking-wide">
                        Chi tiết chuẩn bị cho {name}
                      </p>
                      <div className="text-xs space-y-1 text-text-charcoal">
                        <p><strong className="font-mono text-[10px] text-text-muted block uppercase">Phương thức Đóng gói:</strong> {wrapDetails[wrapOption as keyof typeof wrapDetails].title}</p>
                        <p><strong className="font-mono text-[10px] text-text-muted block uppercase">Địa điểm Giao hàng:</strong> {address}</p>
                        <p><strong className="font-mono text-[10px] text-text-muted block uppercase">Dự kiến Giao nhận:</strong> 3–5 Chu kỳ Mặt trời</p>
                      </div>
                    </div>

                    <p className="text-xs text-text-muted font-light max-w-sm mb-6 leading-relaxed">
                      Một email xác nhận đã được gửi đến <strong>{email}</strong>. Chúng tôi đang cẩn thận đóng gói các sản phẩm của bạn cùng với các nhành thảo mộc tươi mới thu hoạch. Cảm ơn bạn đã lựa chọn Avaphar.
                    </p>
                    <button
                      onClick={handleSuccessClose}
                      className="w-full py-4 bg-brand-blue hover:bg-brand-blue-light text-bg-cream text-xs font-mono uppercase tracking-wider transition-colors duration-300"
                    >
                      Đóng và Hoàn tất Nghi thức
                    </button>
                  </div>
                )}

              </div>

              {/* Sidebar Sticky Footer (Totals and CTAs) */}
              {cart.length > 0 && step !== 'success' && (
                <div className="px-6 py-6 border-t border-border-bone bg-bg-beige/25">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-mono uppercase tracking-widest text-text-muted">Tạm tính</span>
                    <span className="font-mono text-lg font-semibold text-text-charcoal">${subtotal.toFixed(2)}</span>
                  </div>
                  
                  <div className="text-[11px] text-text-muted font-light flex items-center space-x-1.5 mb-6">
                    <Sparkles size={12} className="text-brand-yellow shrink-0" />
                    <span>Miễn phí vận chuyển hữu cơ trong sợi mặt trời tái chế.</span>
                  </div>

                  {step === 'cart' ? (
                    <button
                      onClick={() => setStep('details')}
                      className="w-full py-4 bg-brand-blue hover:bg-brand-blue-light text-bg-cream text-xs font-mono uppercase tracking-wider transition-colors duration-300 flex items-center justify-center space-x-2 cursor-pointer"
                    >
                      <span>Tiến hành Giao hàng & Đóng gói</span>
                    </button>
                  ) : (
                    <div className="flex space-x-3">
                      <button
                        type="button"
                        onClick={() => setStep('cart')}
                        className="w-1/3 py-4 border border-border-bone hover:border-text-muted text-text-charcoal text-xs font-mono uppercase tracking-wider transition-colors duration-300"
                      >
                        Quay lại
                      </button>
                      <button
                        type="button"
                        onClick={handleCheckoutSubmit}
                        className="w-2/3 py-4 bg-brand-red hover:bg-brand-red-light text-bg-cream text-xs font-mono uppercase tracking-wider transition-colors duration-300 cursor-pointer"
                      >
                        Hoàn tất Đơn hàng
                      </button>
                    </div>
                  )}
                </div>
              )}

            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
