import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import ProductCard from './components/ProductCard';
import CartSidebar from './components/CartSidebar';
import { collections, products, ingredients, journalArticles, brandValues } from './data';
import { Product, Collection, Ingredient, JournalArticle, CartItem } from './types';
import { 
  Sparkles, 
  Clock, 
  Check, 
  ArrowRight, 
  Mail, 
  Phone, 
  MapPin, 
  Award, 
  ChevronDown, 
  ChevronUp, 
  Compass, 
  Info,
  Calendar,
  User,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';

export default function App() {
  // Page routing state
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [selectedCollectionId, setSelectedCollectionId] = useState<string | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(null);
  const [selectedIngredientId, setSelectedIngredientId] = useState<string | null>(null);

  // Commerce state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  // Interaction States
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeFaqIndex, setActiveFaqIndex] = useState<number | null>(null);
  const [activeProductTab, setActiveProductTab] = useState<'benefits' | 'ingredients' | 'howtouse'>('benefits');
  const [ingredientFilter, setIngredientFilter] = useState<string>('all');
  const [journalFilter, setJournalFilter] = useState<string>('all');
  const [productGalleryIndex, setProductGalleryIndex] = useState(0);

  // Form states
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [contactSubmitted, setContactSubmitted] = useState(false);

  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubmitted, setNewsletterSubmitted] = useState(false);

  // Cart persistence
  useEffect(() => {
    const savedCart = localStorage.getItem('avaphar_cart');
    if (savedCart) {
      try {
        setCart(JSON.parse(savedCart));
      } catch (e) {
        console.error('Error parsing cart data', e);
      }
    }
  }, []);

  const saveCart = (newCart: CartItem[]) => {
    setCart(newCart);
    localStorage.setItem('avaphar_cart', JSON.stringify(newCart));
  };

  // Cart actions
  const handleAddToCart = (product: Product, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const existingIndex = cart.findIndex((item) => item.product.id === product.id);
    let updatedCart: CartItem[];
    if (existingIndex > -1) {
      updatedCart = [...cart];
      updatedCart[existingIndex].quantity += 1;
    } else {
      updatedCart = [...cart, { product, quantity: 1 }];
    }
    saveCart(updatedCart);
    setCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    const updatedCart = cart
      .map((item) => (item.product.id === productId ? { ...item, quantity } : item))
      .filter((item) => item.quantity > 0);
    saveCart(updatedCart);
  };

  const handleRemoveItem = (productId: string) => {
    const updatedCart = cart.filter((item) => item.product.id !== productId);
    saveCart(updatedCart);
  };

  const handleClearCart = () => {
    saveCart([]);
  };

  // Routing Helpers
  const handleViewProduct = (product: Product) => {
    setSelectedProductId(product.id);
    setProductGalleryIndex(0);
    setActiveProductTab('benefits');
    setCurrentPage('product-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewArticle = (article: JournalArticle) => {
    setSelectedArticleId(article.id);
    setCurrentPage('article-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewCollection = (collectionId: string) => {
    setSelectedCollectionId(collectionId);
    setCurrentPage('collections');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewIngredient = (ingredient: Ingredient) => {
    setSelectedIngredientId(ingredient.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      setNewsletterSubmitted(true);
      setNewsletterEmail('');
    }
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (contactName.trim() && contactEmail.trim() && contactMessage.trim()) {
      setContactSubmitted(true);
      setContactName('');
      setContactEmail('');
      setContactMessage('');
    }
  };

  // Testimonial quotes
  const testimonials = [
    {
      quote: "Avaphar đã thay đổi hoàn toàn thói quen buổi sáng của tôi. Cảm giác mát lạnh và đầm tay từ bánh bùn khoáng đất nung, sau đó là xịt dưỡng sinh học đại dương, làm tôi cảm thấy như được kết nối sâu sắc với đất trời trước khi bước vào thế giới ảo của màn hình máy tính.",
      author: "Evelyn Sterling",
      role: "Kiến trúc sư & Đại sứ Lối sống Chậm"
    },
    {
      quote: "Dầu dưỡng thể Solar Honey mang một hơi ấm tự nhiên dễ chịu của những ngày ngập nắng mà không hề có cảm giác nhân tạo. Nó như những bông hoa thảo mộc đích thực và mật ong đang tan chảy dịu dàng trên da.",
      author: "Julian Mercer",
      role: "Họa sĩ Minh họa Thảo mộc"
    },
    {
      quote: "Dưới góc độ chuyên môn da liễu, tôi đánh giá cao sự chân thật hoàn toàn về bảng thành phần cấu trúc của họ. Các hoạt chất sinh học biển ép lạnh trong dòng METABI mang lại độ ẩm vô cùng ổn định mà không chứa chất độn.",
      author: "TS. Clara Thorne",
      role: "Nhà nghiên cứu Sinh học Da"
    }
  ];

  // FAQs
  const faqItems = [
    {
      question: "Vì sao thương hiệu lựa chọn Xanh, Vàng và Đỏ làm màu sắc nhận diện?",
      answer: "Đây là những cột trụ nền tảng tạo nên hệ sinh thái của chúng tôi. Màu xanh tượng trưng cho dòng sản phẩm dưỡng da METABI chiết xuất từ nước đại dương và sinh vật phù du. Màu vàng tượng trưng cho nến hổ phách và dầu dưỡng thể thảo mộc chiết xuất mật ong rừng hoang dã và yến mạch ấm áp. Màu đỏ đại diện cho xà phòng đất sét nung và hạt tầm xuân giàu khoáng chất. Đó là những màu sắc cốt lõi của thương hiệu, được thể hiện ở dạng nguyên bản thuần khiết nhất từ thiên nhiên."
    },
    {
      question: "Các thành phần có đảm bảo phân hủy sinh học 100% và khai thác bền vững không?",
      answer: "Có. Từ đất sét Pháp được khai thác nhân văn cho đến hạt tầm xuân được thu hoạch thủ công hoang dã, chúng tôi luôn truy xuất nguồn gốc của từng hoạt chất sinh học về chính xác vùng đất trồng hữu cơ ban đầu. Chai lọ thủy tinh của chúng tôi có thể tái chế vô hạn và bao bì đóng gói được làm từ giấy sợi bạch đàn và yến mạch tự hủy sinh học hoàn toàn."
    },
    {
      question: "Công thức giả kim ép lạnh là gì?",
      answer: "Khác với mỹ phẩm công nghiệp đun sôi nguyên liệu để tăng tốc độ nhũ hóa—vô tình phá hủy các vitamin thực vật nhạy cảm và enzym thảo mộc—chúng tôi xử lý tất cả chiết xuất ở nhiệt độ phòng tự nhiên. Đất sét nung của chúng tôi được phơi nắng chậm rãi trong 14 ngày, và xà phòng tắm được ủ trong phòng gỗ tuyết tùng tối suốt 6 tuần để bảo tồn hoạt tính khoáng chất ở mức cao nhất."
    },
    {
      question: "Các cửa hàng đối tác vật lý nằm ở đâu?",
      answer: "Sản phẩm của Avaphar được phân phối độc quyền tại các không gian triển lãm lối sống chậm, phòng khám da liễu thảo mộc bền vững và phòng trưng bày thiết kế hữu cơ được tuyển chọn tại Đà Lạt, Hà Nội, Tokyo và Copenhagen. Bạn có thể xem lưới đối tác hiện tại của chúng tôi trên trang Liên hệ."
    }
  ];

  // Find detailed models based on IDs
  const activeProduct = products.find((p) => p.id === selectedProductId);
  const activeCollection = collections.find((c) => c.id === selectedCollectionId);
  const activeArticle = journalArticles.find((a) => a.id === selectedArticleId);
  const activeIngredient = ingredients.find((i) => i.id === selectedIngredientId);

  return (
    <div className="min-h-screen flex flex-col bg-bg-cream selection:bg-brand-yellow-light selection:text-text-charcoal antialiased">
      

      {/* HEADER COMPONENT */}
      <Header
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        selectedCollectionId={selectedCollectionId}
        onSelectCollection={setSelectedCollectionId}
        cart={cart}
        onOpenCart={() => setCartOpen(true)}
        menuOpen={menuOpen}
        setMenuOpen={setMenuOpen}
      />

      {/* MAIN RENDER ENGINE */}
      <main className="flex-grow">
        
        {/* ========================================================= */}
        {/* PAGE: HOME */}
        {/* ========================================================= */}
        {currentPage === 'home' && (
          <div className="animate-fade-in space-y-24">
            
            {/* HERO SECTION */}
            <section className="relative min-h-[90vh] py-20 pb-32 flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 z-0">
                <img
                  src="https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?q=80&w=1600&auto=format&fit=crop"
                  alt="Deep Forest Sunlight"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover brightness-[0.75]"
                />
              </div>

              {/* Core Hero Branding Frame */}
              <div className="relative z-10 max-w-4xl mx-auto text-center px-4 space-y-6 text-bg-cream">
                <span className="text-[10px] sm:text-xs font-mono uppercase tracking-[0.3em] text-brand-yellow-light block">
                  Phòng Thí Nghiệm Thiên Nhiên AVAPHAR
                </span>
                <h1 className="font-serif text-4xl sm:text-5xl md:text-[67px] font-light tracking-wide leading-[1.1] text-bg-cream">
                  Where Nature Becomes Care
                </h1>
                <p className="font-sans text-sm sm:text-base font-light text-bg-cream/90 max-w-xl mx-auto leading-relaxed">
                  Chúng tôi chuyển hóa các màu sắc biểu tượng đại diện — <span className="text-brand-blue-light font-medium">Xanh</span>, <span className="text-brand-yellow font-medium">Vàng</span>, và <span className="text-brand-red-light font-medium">Đỏ</span> — thành những thành phần phục hồi sâu sắc nhất của Trái Đất: Sinh vật phù du biển, Mật ong rừng và Đất sét khoáng nung.
                </p>
                <div className="pt-6 flex flex-row items-center justify-center space-x-3 sm:space-x-4">
                  <button
                    onClick={() => {
                      setCurrentPage('collections');
                      setSelectedCollectionId(null);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="px-4 sm:px-8 py-3.5 sm:py-4 bg-bg-cream hover:bg-bg-beige text-text-charcoal text-[10px] sm:text-xs font-mono uppercase tracking-widest transition-all duration-300 whitespace-nowrap"
                  >
                    Khám Phá Bộ Sưu Tập
                  </button>
                  <button
                    onClick={() => {
                      setCurrentPage('about');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="px-4 sm:px-8 py-3.5 sm:py-4 border border-bg-cream/50 hover:bg-bg-cream/10 text-bg-cream text-[10px] sm:text-xs font-mono uppercase tracking-widest transition-all duration-300 whitespace-nowrap"
                  >
                    Câu Chuyện Khởi Nguồn
                  </button>
                </div>
              </div>

              {/* Scroll down indicator line */}
              <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center space-y-2 text-bg-cream/65 z-10">
                <span className="text-[9px] font-mono uppercase tracking-widest">Khám phá</span>
                <div className="w-[1px] h-12 bg-bg-cream/30 relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1/2 bg-brand-yellow animate-bounce"></div>
                </div>
              </div>
            </section>

            {/* BRAND PHILOSOPHY */}
            <section className="max-w-4xl mx-auto px-4 text-center space-y-6 pt-12">
              <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-blue font-medium block">
                Triết Lý Chiết Xuất Chân Thật
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-light text-text-charcoal tracking-wide">
                “Vẻ đẹp là sự tích lũy chậm rãi theo chu kỳ — không phải là sự bùng nổ hóa chất cấp tốc.”
              </h2>
              <div className="w-12 h-[1px] bg-border-bone mx-auto"></div>
              <p className="text-sm text-text-muted font-light leading-relaxed max-w-2xl mx-auto">
                Tại Avaphar, chúng tôi từ chối sự vội vã công nghiệp của ngành chăm sóc cá nhân tổng hợp. Chúng tôi tôn trọng các chu kỳ tự nhiên bằng cách ép lạnh từng mẫu vật, cho phép các hoạt chất thực vật tự nhũ hóa theo tốc độ riêng của chúng. Bằng cách định hình danh tính của mình trong phổ nguyên tố của tự nhiên, chúng tôi tạo ra những công thức trung thực để tôn trọng hàng rào bảo vệ tế bào của bạn.
              </p>
            </section>

            {/* SPLIT LAYOUT: NATURE + SCIENCE */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                
                {/* Left: Close up image */}
                <div className="relative aspect-[4/5] bg-bg-beige overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?q=80&w=800&auto=format&fit=crop"
                    alt="Botanical Leaf Texture"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover filter brightness-[0.9]"
                  />
                  <div className="absolute bottom-6 left-6 bg-bg-cream/80 backdrop-blur-sm p-4 border border-border-bone/60 max-w-xs">
                    <span className="text-[10px] font-mono text-text-muted uppercase block mb-1">Mẫu Vật số #890</span>
                    <p className="text-xs font-serif text-text-charcoal italic">"Sự cấp ẩm tế bào tự nhiên xảy ra khi các phức hợp khoáng chất mô phỏng độ mặn sinh học của làn da."</p>
                  </div>
                </div>

                {/* Right: Explanatory text */}
                <div className="space-y-6">
                  <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-red font-medium block">
                    Khoa Học Nguyên Bản
                  </span>
                  <h3 className="font-serif text-3xl sm:text-4xl font-light text-text-charcoal tracking-wide leading-tight">
                    Thủ công truyền thống kết hợp hóa sinh tế bào.
                  </h3>
                  <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed">
                    Chúng tôi kết nối trí tuệ cảm quan của những nhà thảo dược truyền thống với khoa học chuyên sâu về da. Chúng tôi không chỉ cung cấp chiết xuất thiên nhiên thông thường; chúng tôi lên men bùn đại dương, ép lạnh hạt lipid giàu dinh dưỡng và bảo tồn nguyên vẹn các enzym sống của hoa hoang dã.
                  </p>
                  
                  {/* Natural elements statistics */}
                  <div className="grid grid-cols-3 gap-6 pt-6 border-t border-border-bone">
                    <div className="space-y-1">
                      <span className="block font-serif text-3xl font-light text-brand-blue">98.4%</span>
                      <span className="block text-[10px] font-mono text-text-muted uppercase tracking-wider">Chiết xuất Tự nhiên</span>
                    </div>
                    <div className="space-y-1">
                      <span className="block font-serif text-3xl font-light text-brand-yellow">14 Ngày</span>
                      <span className="block text-[10px] font-mono text-text-muted uppercase tracking-wider">Đất sét phơi nắng</span>
                    </div>
                    <div className="space-y-1">
                      <span className="block font-serif text-3xl font-light text-brand-red">0%</span>
                      <span className="block text-[10px] font-mono text-text-muted uppercase tracking-wider">Chất độn tổng hợp</span>
                    </div>
                  </div>

                  <div className="pt-4">
                    <button
                      onClick={() => {
                        setCurrentPage('about');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="text-xs uppercase font-mono tracking-wider text-text-charcoal hover:text-brand-blue border-b border-text-charcoal pb-1 transition-all"
                    >
                      Trụ cột Khoa học của Chúng tôi →
                    </button>
                  </div>
                </div>

              </div>
            </section>

            {/* FEATURED COLLECTIONS GRID (The Three Elements represent Blue, Yellow, Red) */}
            <section className="bg-bg-beige/40 py-24 border-y border-border-bone/50">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
                <div className="text-center space-y-2">
                  <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-text-muted block">
                    Bộ Ba Nguyên Bản
                  </span>
                  <h3 className="font-serif text-3xl font-light text-text-charcoal tracking-wide">
                    Ba Dòng Sản Phẩm Nguyên Tố Tự Nhiên
                  </h3>
                  <p className="text-xs text-text-muted font-light max-w-md mx-auto">
                    Khám phá các dòng sản phẩm đặc trưng của chúng tôi, mỗi bộ sưu tập được khơi nguồn cảm hứng từ mã màu đại diện của thiên nhiên.
                  </p>
                </div>

                {/* 3-Column Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {collections.map((col) => {
                    const highlightClass = 
                      col.colorTheme === 'blue' 
                        ? 'border-brand-blue/30 text-brand-blue hover:bg-brand-blue/5' 
                        : col.colorTheme === 'yellow'
                        ? 'border-brand-yellow/30 text-brand-yellow hover:bg-brand-yellow/5'
                        : 'border-brand-red/30 text-brand-red hover:bg-brand-red/5';

                    return (
                      <div 
                        key={col.id}
                        className="group flex flex-col bg-bg-cream/50 backdrop-blur-md border border-border-bone/60 hover:border-brand-blue/60 hover:shadow-sm rounded-[32px] p-2 transition-all duration-500 overflow-hidden"
                      >
                        <div className="aspect-[3/4] overflow-hidden bg-bg-beige relative rounded-[24px]">
                          <img
                            src={col.image}
                            alt={col.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-text-charcoal/80 via-text-charcoal/10 to-transparent flex flex-col justify-end p-6">
                            <span className="text-[10px] font-mono text-bg-cream/70 uppercase tracking-widest block mb-1">
                              Collection Series
                            </span>
                            <h4 className="font-serif text-2xl text-bg-cream tracking-wide font-light">
                              {col.name}
                            </h4>
                          </div>
                        </div>

                        <div className="p-5 flex flex-col flex-grow space-y-4">
                          <p className="text-xs text-text-muted font-light leading-relaxed line-clamp-3">
                            {col.introduction}
                          </p>
                          <div className="pt-2 mt-auto">
                            <button
                              onClick={() => handleViewCollection(col.id)}
                              className={`w-full py-3 border text-xs font-mono uppercase tracking-widest rounded-full transition-all duration-300 ${highlightClass}`}
                            >
                              Discover series
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </section>

            {/* SIGNATURE INGREDIENTS SPECIMEN LIST */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
              <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-4">
                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-yellow font-medium block">
                    Danh mục Mẫu vật Thảo mộc
                  </span>
                  <h3 className="font-serif text-3xl font-light text-text-charcoal tracking-wide">
                    Các Hoạt Chất Chủ Đạo
                  </h3>
                </div>
                <button
                  onClick={() => {
                    setCurrentPage('ingredients');
                    setIngredientFilter('all');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-xs uppercase font-mono tracking-widest text-text-charcoal hover:text-brand-blue border-b border-text-charcoal pb-1 transition-all"
                >
                  Thư viện Thành phần →
                </button>
              </div>

              {/* Static Grid for aesthetic curation */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {ingredients.map((ing) => (
                  <div 
                    key={ing.id}
                    onClick={() => {
                      setCurrentPage('ingredients');
                      setSelectedIngredientId(ing.id);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="group bg-bg-cream/40 hover:bg-bg-cream/85 backdrop-blur-md border border-border-bone/60 hover:border-brand-blue/50 rounded-[32px] p-6 text-center space-y-4 transition-all duration-500 cursor-pointer hover:shadow-sm animate-fade-in"
                  >
                    <div className="w-24 h-24 rounded-full overflow-hidden mx-auto bg-bg-beige border border-border-bone/40">
                      <img
                        src={ing.image}
                        alt={ing.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                    </div>
                    <div>
                      <h4 className="font-serif text-base font-medium text-text-charcoal group-hover:text-brand-blue transition-colors">
                        {ing.name}
                      </h4>
                      <span className="text-[10px] font-mono text-text-muted italic block mt-1">
                        {ing.botanicalName}
                      </span>
                    </div>
                    <p className="text-xs text-text-muted font-light line-clamp-2 leading-relaxed">
                      {ing.poeticIntro}
                    </p>
                    <span className="inline-block text-[10px] font-mono text-brand-blue uppercase tracking-widest pt-2 group-hover:underline">
                      Chi tiết Mẫu vật →
                    </span>
                  </div>
                ))}
              </div>
            </section>

            {/* FEATURED PRODUCTS CATALOG */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
              <div className="text-center space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-red font-medium block">
                  Nhà Thuốc Thảo Mộc Tuyển Chọn
                </span>
                <h3 className="font-serif text-3xl font-light text-text-charcoal tracking-wide">
                  Sản phẩm Thiết yếu cho Nghi thức Hàng ngày
                </h3>
              </div>

              {/* Asymmetrical Grid of featured products */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {products.filter(p => p.isFeatured).map((prod) => {
                  const col = collections.find(c => c.id === prod.collectionId);
                  return (
                    <ProductCard
                      key={prod.id}
                      product={prod}
                      onViewDetails={handleViewProduct}
                      onAddToCart={(p, e) => handleAddToCart(p, e)}
                      collectionName={col?.name || ''}
                      collectionColor={col?.colorTheme || 'blue'}
                    />
                  );
                })}
              </div>

              <div className="text-center pt-4">
                <button
                  onClick={() => {
                    setCurrentPage('collections');
                    setSelectedCollectionId(null);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-8 py-4 bg-brand-blue hover:bg-brand-blue-light text-bg-cream text-xs font-mono uppercase tracking-widest rounded-full transition-all duration-300 shadow-sm"
                >
                  Mua Sắm Toàn Bộ Sản Phẩm
                </button>
              </div>
            </section>

            {/* EDITORIAL STORY BREAK */}
            <section className="relative h-[65vh] flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 z-0">
                <img
                  src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1200&auto=format&fit=crop"
                  alt="Ocean shoreline cinematic"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover brightness-[0.7] transform scale-100 translate-y-0"
                />
              </div>

              {/* Overlapping card offset to bottom left */}
              <div className="absolute bottom-10 left-4 sm:left-10 lg:left-24 max-w-lg z-10 bg-bg-cream/90 backdrop-blur-md p-8 sm:p-10 border border-border-bone/60 rounded-[32px] shadow-lg space-y-4">
                <span className="text-[9px] font-mono uppercase tracking-[0.25em] text-brand-blue font-medium block">
                  Tập san Biên niên sử I
                </span>
                <h4 className="font-serif text-2xl sm:text-3xl text-text-charcoal tracking-wide font-light">
                  Hoạt chất sinh học biển sâu & Sự phục hồi tế bào đại dương.
                </h4>
                <p className="text-xs text-text-muted font-light leading-relaxed">
                  Chúng tôi nghiên cứu cách các sinh vật phù du siêu vi sinh trưởng trong áp suất đại dương cực lớn để chiết xuất các chuỗi peptide làm màng bảo vệ da.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => {
                      const article = journalArticles.find(a => a.id === 'marine-bioactives');
                      if (article) handleViewArticle(article);
                    }}
                    className="text-xs uppercase font-mono tracking-widest text-text-charcoal hover:text-brand-blue border-b border-text-charcoal pb-1 transition-all"
                  >
                    Read the Journal Story →
                  </button>
                </div>
              </div>
            </section>

            {/* CRAFTSMANSHIP SEGMENT */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                
                {/* Content Left */}
                <div className="space-y-6 order-2 lg:order-1">
                  <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-yellow font-medium block">
                    Kỹ nghệ Thủ công
                  </span>
                  <h3 className="font-serif text-3xl sm:text-4xl font-light text-text-charcoal tracking-wide leading-tight">
                    Phòng tuyết tùng và bệ đá phơi nắng. Ủ chậm rãi, tôi luyện dưới nắng ấm.
                  </h3>
                  <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed">
                    Hầu hết các thương hiệu công nghiệp đều đẩy nhanh quá trình sản xuất. Xà phòng của chúng tôi được làm khô chậm trong phòng tuyết tùng tối suốt sáu tuần để đảm bảo lớp bọt dưỡng ẩm mịn màng nhất. Đất sét nung núi lửa được trải phẳng trên phiến đá lớn để phơi dưới ánh mặt trời mùa hè, bảo tồn điện tích khoáng âm nguyên bản.
                  </p>
                  
                  <div className="space-y-4 pt-4 border-t border-border-bone">
                    <div className="flex items-start space-x-3">
                      <span className="font-serif text-sm italic text-brand-red font-medium">01</span>
                      <p className="text-xs text-text-muted"><strong className="font-sans text-xs text-text-charcoal">Công nghệ Ép Ba Lớp:</strong> Đảm bảo bánh xà phòng nén chắc, không hao phí và bền hơn nhiều lần xà phòng thông thường.</p>
                    </div>
                    <div className="flex items-start space-x-3">
                      <span className="font-serif text-sm italic text-brand-red font-medium">02</span>
                      <p className="text-xs text-text-muted"><strong className="font-sans text-xs text-text-charcoal">Ủ Dưỡng Chất Thảo Mộc:</strong> Ủ chín các loại dầu dưỡng trong tủ gỗ tuyết tùng tối với độ ẩm ổn định.</p>
                    </div>
                  </div>

                  <div className="pt-4">
                    <button
                      onClick={() => {
                        setCurrentPage('about');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="text-xs uppercase font-mono tracking-wider text-text-charcoal hover:text-brand-blue border-b border-text-charcoal pb-1 transition-all"
                    >
                      Quy trình Ủ Chậm của Chúng tôi →
                    </button>
                  </div>
                </div>

                {/* Image Right */}
                <div className="relative aspect-[4/5] bg-bg-beige overflow-hidden order-1 lg:order-2">
                  <img
                    src="https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=800&auto=format&fit=crop"
                    alt="Handicraft clay studio"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover filter brightness-[0.95]"
                  />
                </div>

              </div>
            </section>

            {/* TESTIMONIALS CAROUSEL */}
            <section className="bg-bg-beige/40 py-20 border-y border-border-bone/60">
              <div className="max-w-4xl mx-auto px-4 text-center space-y-8">
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-text-muted block">
                  Đánh Giá Từ Khách Hàng
                </span>
                
                <div className="min-h-[140px] flex items-center justify-center">
                  <p className="font-serif text-xl sm:text-2xl font-light text-text-charcoal italic leading-relaxed animate-fade-in">
                    “{testimonials[activeTestimonial].quote}”
                  </p>
                </div>

                <div className="space-y-1">
                  <h5 className="font-sans text-xs font-semibold uppercase tracking-wider text-text-charcoal">
                    {testimonials[activeTestimonial].author}
                  </h5>
                  <p className="text-[11px] font-mono text-text-muted">
                    {testimonials[activeTestimonial].role}
                  </p>
                </div>

                {/* Carousel dots */}
                <div className="flex items-center justify-center space-x-2 pt-4">
                  {testimonials.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveTestimonial(idx)}
                      className={`w-1.5 h-1.5 rounded-full transition-all focus:outline-none ${
                        activeTestimonial === idx ? 'bg-text-charcoal w-6' : 'bg-border-bone'
                      }`}
                    ></button>
                  ))}
                </div>
              </div>
            </section>

            {/* JOURNAL PREVIEW */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
              <div className="flex items-end justify-between">
                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-blue font-medium block">
                    Ấn Phẩm Đọc Chậm
                  </span>
                  <h3 className="font-serif text-3xl font-light text-text-charcoal tracking-wide">
                    Từ kho mục Tập san
                  </h3>
                </div>
                <button
                  onClick={() => {
                    setCurrentPage('journal');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-xs uppercase font-mono tracking-widest text-text-charcoal hover:text-brand-blue border-b border-text-charcoal pb-1 transition-all"
                >
                  Đọc tất cả bài viết →
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {journalArticles.map((article) => (
                  <div 
                    key={article.id}
                    onClick={() => handleViewArticle(article)}
                    className="group flex flex-col space-y-4 cursor-pointer"
                  >
                    <div className="aspect-[4/5] bg-bg-beige overflow-hidden border border-border-bone/40">
                      <img
                        src={article.image}
                        alt={article.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-103 brightness-[0.95]"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-[10px] font-mono text-text-muted uppercase tracking-wider">
                        <span>{article.category}</span>
                        <span>·</span>
                        <span>{article.readTime}</span>
                      </div>
                      <h4 className="font-serif text-lg font-medium text-text-charcoal group-hover:text-brand-blue transition-colors leading-snug">
                        {article.title}
                      </h4>
                      <p className="text-xs text-text-muted font-light leading-relaxed line-clamp-2">
                        {article.excerpt}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* INSTAGRAM LIFESTYLE PREVIEW */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 pb-12">
              <div className="text-center">
                <span className="text-[10px] font-mono uppercase tracking-widest text-text-muted">
                  Nhịp Điệu Thẩm Mỹ · @avaphar.laboratory
                </span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="aspect-square bg-bg-beige overflow-hidden border border-border-bone/30">
                  <img src="https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=300&auto=format&fit=crop" alt="Avaphar serum" referrerPolicy="no-referrer" className="w-full h-full object-cover filter saturate-50 hover:saturate-100 transition-all duration-500" />
                </div>
                <div className="aspect-square bg-bg-beige overflow-hidden border border-border-bone/30">
                  <img src="https://images.unsplash.com/photo-1546554137-f86b9593a222?q=80&w=300&auto=format&fit=crop" alt="Avaphar bar soap" referrerPolicy="no-referrer" className="w-full h-full object-cover filter saturate-50 hover:saturate-100 transition-all duration-500" />
                </div>
                <div className="aspect-square bg-bg-beige overflow-hidden border border-border-bone/30">
                  <img src="https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=300&auto=format&fit=crop" alt="Glow ambiance" referrerPolicy="no-referrer" className="w-full h-full object-cover filter saturate-50 hover:saturate-100 transition-all duration-500" />
                </div>
                <div className="aspect-square bg-bg-beige overflow-hidden border border-border-bone/30">
                  <img src="https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?q=80&w=300&auto=format&fit=crop" alt="Avaphar body oil" referrerPolicy="no-referrer" className="w-full h-full object-cover filter saturate-50 hover:saturate-100 transition-all duration-500" />
                </div>
                <div className="aspect-square bg-bg-beige overflow-hidden border border-border-bone/30">
                  <img src="https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?q=80&w=300&auto=format&fit=crop" alt="Rosehip close-up" referrerPolicy="no-referrer" className="w-full h-full object-cover filter saturate-50 hover:saturate-100 transition-all duration-500" />
                </div>
              </div>
            </section>

          </div>
        )}

        {/* ========================================================= */}
        {/* PAGE: ABOUT */}
        {/* ========================================================= */}
        {currentPage === 'about' && (
          <div className="animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-24">
            
            {/* Philosophy Header */}
            <section className="max-w-3xl mx-auto text-center space-y-6 pt-8">
              <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-brand-blue block">
                Tuyên Ngôn Nguyên Bản
              </span>
              <h1 className="font-serif text-4xl sm:text-5xl font-light text-text-charcoal tracking-wide leading-tight">
                Thành phần chân thật thu hoạch theo chu kỳ tự nhiên thô sơ.
              </h1>
              <p className="text-sm text-text-muted font-light leading-relaxed">
                Avaphar được khởi nguồn từ khao khát kết nối thói quen chăm sóc cá nhân với nguồn gốc địa lý của Trái Đất. Chúng tôi theo dõi từng chiếc lá, từng thỏi đất sét bùn và từng peptide biển sâu trở lại chính xác chu kỳ thu hoạch của chúng, hoàn toàn không lạm dụng chất ổn định tổng hợp.
              </p>
            </section>

            {/* Our Journey Split */}
            <section className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
              <div className="aspect-[4/5] bg-bg-beige overflow-hidden border border-border-bone/50">
                <img
                  src="https://images.unsplash.com/photo-1501854140801-50d01698950b?q=80&w=800&auto=format&fit=crop"
                  alt="Scenic wild mountains"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover brightness-[0.95]"
                />
              </div>
              <div className="space-y-6">
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-red font-medium block">
                  Nguồn gốc từ Đất đến Da
                </span>
                <h3 className="font-serif text-3xl font-light text-text-charcoal tracking-wide leading-tight">
                  Sinh ra ở chân núi hoang dã, tinh chế trong phòng nghiên cứu hiện đại.
                </h3>
                <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed">
                  Chúng tôi thu thập hạt tầm xuân hoang dã ở các thung lũng cao sau khi sương giá đầu đông cô đặc các dưỡng chất lipid. Chúng tôi lọc sinh vật phù du biển từ các vùng thềm lục địa lạnh giá. Chúng tôi phơi khô đất sét đỏ nung trên đá ở các thung lũng phía nam đầy nắng.
                </p>
                <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed">
                  Phòng thí nghiệm của chúng tôi kết hợp các thành phần thô này với các lipid tương thích sinh học, đảm bảo công thức cuối cùng thẩm thấu hoàn hảo vào ma trận tế bào da của bạn mà không cần màng ngăn tổng hợp.
                </p>
                <div className="flex items-center space-x-6 pt-4 border-t border-border-bone">
                  <div className="text-center">
                    <span className="block font-serif text-2xl font-light text-text-charcoal">Thành lập</span>
                    <span className="block text-[10px] font-mono text-text-muted uppercase">2026</span>
                  </div>
                  <div className="text-center">
                    <span className="block font-serif text-2xl font-light text-text-charcoal">100%</span>
                    <span className="block text-[10px] font-mono text-text-muted uppercase">Chân thật</span>
                  </div>
                  <div className="text-center">
                    <span className="block font-serif text-2xl font-light text-text-charcoal">Tái chế</span>
                    <span className="block text-[10px] font-mono text-text-muted uppercase">Thủy tinh Hổ phách</span>
                  </div>
                </div>
              </div>
            </section>

            {/* Our Process Sequence */}
            <section className="space-y-12">
              <div className="text-center space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-yellow font-medium block">
                  Quy trình Chăm sóc Chậm
                </span>
                <h3 className="font-serif text-3xl font-light text-text-charcoal tracking-wide">
                  Ba Giai Đoạn Bào Chế Chậm
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div className="space-y-4 p-6 border border-border-bone/60 bg-bg-beige/10">
                  <span className="font-serif text-4xl font-light text-brand-blue block">01</span>
                  <h4 className="font-serif text-lg font-medium text-text-charcoal">Thu Hoạch Theo Mùa</h4>
                  <p className="text-xs text-text-muted font-light leading-relaxed">
                    Chúng tôi chỉ thu hoạch nguyên liệu vào thời kỳ hoạt chất cô đặc cao nhất. Phù du vào đầu xuân, mật ong rừng vào giữa hè và tầm xuân sau đợt sương giá đầu thu.
                  </p>
                </div>
                <div className="space-y-4 p-6 border border-border-bone/60 bg-bg-beige/10">
                  <span className="font-serif text-4xl font-light text-brand-yellow block">02</span>
                  <h4 className="font-serif text-lg font-medium text-text-charcoal">Phơi Nắng Tự Nhiên</h4>
                  <p className="text-xs text-text-muted font-light leading-relaxed">
                    Chúng tôi trải phẳng bùn khoáng và đất sét trên các phiến đá lớn dưới ánh nắng tự nhiên trong 14 ngày để bảo tồn điện tích ion âm hoạt động.
                  </p>
                </div>
                <div className="space-y-4 p-6 border border-border-bone/60 bg-bg-beige/10">
                  <span className="font-serif text-4xl font-light text-brand-red block">03</span>
                  <h4 className="font-serif text-lg font-medium text-text-charcoal">Ủ Gỗ Tuyết Tùng</h4>
                  <p className="text-xs text-text-muted font-light leading-relaxed">
                    Xà phòng ép lạnh được cắt thủ công và xếp trên kệ gỗ tuyết tùng tự nhiên suốt sáu tuần để phát triển lớp bọt kem lipid dồi dào dưỡng chất.
                  </p>
                </div>
              </div>
            </section>

            {/* Our Values Grid */}
            <section className="bg-bg-beige/40 py-16 px-8 border border-border-bone/80 space-y-12">
              <div className="text-center space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-text-muted block">
                  Trụ Cột Cốt Lõi
                </span>
                <h3 className="font-serif text-3xl font-light text-text-charcoal tracking-wide">
                  Giá trị Từ Đất Đến Da Không
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {brandValues.map((val, idx) => (
                  <div key={idx} className="space-y-2 text-center md:text-left">
                    <span className="text-[10px] font-mono text-brand-blue font-medium block">
                      Giá trị số No. 0{idx + 1}
                    </span>
                    <h4 className="font-serif text-lg font-medium text-text-charcoal">
                      {val.name}
                    </h4>
                    <p className="text-xs text-text-muted font-light leading-relaxed">
                      {val.description}
                    </p>
                  </div>
                ))}
              </div>
            </section>

            {/* Timeline Milestones */}
            <section className="space-y-12 max-w-4xl mx-auto">
              <div className="text-center space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-red font-medium block">
                  Biên Niên Sử
                </span>
                <h3 className="font-serif text-3xl font-light text-text-charcoal tracking-wide">
                  Cột Mốc Phát Triển Chậm
                </h3>
              </div>

              <div className="relative border-l border-border-bone pl-6 ml-4 space-y-10">
                <div className="relative">
                  <span className="absolute -left-[31px] top-1.5 w-2 h-2 rounded-full bg-brand-blue border-4 border-bg-cream ring-1 ring-border-bone"></span>
                  <span className="font-mono text-xs text-brand-blue block">Mùa Xuân 2026</span>
                  <h4 className="font-serif text-base font-medium text-text-charcoal mt-1">Hợp Chất Hệ Sinh Thái</h4>
                  <p className="text-xs text-text-muted font-light mt-1">
                    Phát triển tinh chất sinh học phù du biển METABI đầu tiên kết hợp cùng các chuyên gia đại dương học thềm lục địa phía bắc.
                  </p>
                </div>
                <div className="relative">
                  <span className="absolute -left-[31px] top-1.5 w-2 h-2 rounded-full bg-brand-yellow border-4 border-bg-cream ring-1 ring-border-bone"></span>
                  <span className="font-mono text-xs text-brand-yellow block">Mùa Hè 2026</span>
                  <h4 className="font-serif text-base font-medium text-text-charcoal mt-1">Phát Triển Phơi Nắng Mặt Trời</h4>
                  <p className="text-xs text-text-muted font-light mt-1">
                    Hoàn thiện các bệ phơi đất sét dưới nắng mặt trời tại thung lũng cao phía nam, mở ra phương pháp phơi nắng khoáng 14 ngày truyền thống.
                  </p>
                </div>
                <div className="relative">
                  <span className="absolute -left-[31px] top-1.5 w-2 h-2 rounded-full bg-brand-red border-4 border-bg-cream ring-1 ring-border-bone"></span>
                  <span className="font-mono text-xs text-brand-red block">Mùa Thu 2026</span>
                  <h4 className="font-serif text-base font-medium text-text-charcoal mt-1">Ra Mắt & Nền Tảng Kỹ Thuật Số</h4>
                  <p className="text-xs text-text-muted font-light mt-1">
                    Phát hành rộng rãi toàn bộ bộ sản phẩm chăm sóc thảo mộc nguyên bản, đóng gói trong các bọc lá khuynh diệp phân hủy hữu cơ.
                  </p>
                </div>
              </div>
            </section>

            {/* Founder's Letter */}
            <section className="max-w-2xl mx-auto bg-bg-beige/25 p-8 sm:p-12 border border-border-bone/80 space-y-6">
              <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-brand-yellow font-medium block text-center">
                Thư từ Nhà sáng lập
              </span>
              <p className="font-serif text-lg font-light text-text-charcoal italic leading-relaxed text-center">
                “Chăm sóc cá nhân không nên dựa vào các bí mật hóa học phức tạp. Làn da của bạn tự tương thích và nhận biết được nồng độ mặn của đại dương, các enzym của mật ong rừng nguyên chất, và sức hút thanh lọc của đất sét đỏ tự nhiên. Chúng tôi xây dựng sản phẩm bằng sự chân thật, để làn da bạn được an nghỉ.”
              </p>
              <div className="text-center pt-4 space-y-1">
                <span className="block font-serif text-base text-text-charcoal font-medium">Evelyn Sterling</span>
                <span className="block text-[10px] font-mono text-text-muted uppercase">Nhà sáng lập Avaphar Lab</span>
              </div>
            </section>

          </div>
        )}

        {/* ========================================================= */}
        {/* PAGE: COLLECTIONS */}
        {/* ========================================================= */}
        {currentPage === 'collections' && (
          <div className="animate-fade-in">
            
            {/* NO SELECTED COLLECTION: SHOW TRILOGY OVERVIEW */}
            {!selectedCollectionId ? (
              <div className="space-y-24">
                
                {/* Header */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 text-center max-w-3xl space-y-4">
                  <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-brand-blue block">
                    Bộ Ba Nguyên Bản
                  </span>
                  <h1 className="font-serif text-4xl sm:text-5xl font-light text-text-charcoal tracking-wide">
                    Ba Dòng Màu Sắc Tự Nhiên
                  </h1>
                  <p className="text-sm text-text-muted font-light max-w-2xl mx-auto leading-relaxed">
                    Chúng tôi chuyển hóa các màu sắc đại diện cho phòng thí nghiệm — xanh dương, vàng, đỏ — thành các nguyên liệu tự nhiên chân thực. Khám phá cách mỗi yếu tố phục hồi sức khỏe tế bào da.
                  </p>
                </section>

                {/* Vertical stacked huge sections */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-32 pb-16">
                  {collections.map((col, index) => {
                    const isEven = index % 2 === 0;
                    const accentText = 
                      col.colorTheme === 'blue' 
                        ? 'text-brand-blue' 
                        : col.colorTheme === 'yellow'
                        ? 'text-brand-yellow'
                        : 'text-brand-red';

                    const accentBtn =
                      col.colorTheme === 'blue' 
                        ? 'bg-brand-blue hover:bg-brand-blue-light' 
                        : col.colorTheme === 'yellow'
                        ? 'bg-brand-yellow hover:bg-brand-yellow-light'
                        : 'bg-brand-red hover:bg-brand-red-light';

                    const vietNameColor =
                      col.colorTheme === 'blue'
                        ? 'Xanh dương (Nước)'
                        : col.colorTheme === 'yellow'
                        ? 'Vàng (Mặt trời)'
                        : 'Đỏ (Đất sét)';

                    return (
                      <div 
                        key={col.id}
                        className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-center"
                      >
                        {/* Image Column */}
                        <div className={`lg:col-span-7 aspect-[16/10] bg-bg-beige overflow-hidden border border-border-bone/40 ${isEven ? 'lg:order-1' : 'lg:order-2'}`}>
                          <img
                            src={col.image}
                            alt={col.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover filter brightness-[0.93]"
                          />
                        </div>

                        {/* Text Column */}
                        <div className={`lg:col-span-5 space-y-6 ${isEven ? 'lg:order-2' : 'lg:order-1'}`}>
                          <span className={`text-[10px] font-mono uppercase tracking-[0.2em] font-medium block ${accentText}`}>
                            DÒNG MÀU: {vietNameColor.toUpperCase()}
                          </span>
                          <h2 className="font-serif text-3xl sm:text-4xl font-light text-text-charcoal tracking-wide leading-tight">
                            {col.name}
                          </h2>
                          <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed">
                            {col.description}
                          </p>
                          <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed">
                            {col.introduction}
                          </p>
                          <div className="pt-4">
                            <button
                              onClick={() => handleViewCollection(col.id)}
                              className={`px-8 py-3.5 text-bg-cream text-xs font-mono uppercase tracking-widest transition-colors duration-300 cursor-pointer ${accentBtn}`}
                            >
                              Khám phá dòng {col.colorTheme === 'blue' ? 'Xanh dương' : col.colorTheme === 'yellow' ? 'Vàng' : 'Đỏ'} →
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </section>

              </div>
            ) : (
              
              /* INDIVIDUAL COLLECTION DETAIL VIEW */
              <div className="space-y-24">
                
                {/* Dynamic Collection Hero */}
                <section className="relative h-[65vh] flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 z-0">
                    <img
                      src={activeCollection?.image}
                      alt={activeCollection?.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover brightness-[0.7]"
                    />
                  </div>
                  <div className="relative z-10 max-w-4xl mx-auto text-center px-4 space-y-4 text-bg-cream">
                    <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-brand-yellow-light block">
                      Dòng Nguyên Tố: {activeCollection?.colorTheme === 'blue' ? 'XANH DƯƠNG (NƯỚC)' : activeCollection?.colorTheme === 'yellow' ? 'VÀNG (MẶT TRỜI)' : 'ĐỎ (ĐẤT SÉT)'}
                    </span>
                    <h1 className="font-serif text-4xl sm:text-6xl font-light tracking-wide text-bg-cream">
                      {activeCollection?.name}
                    </h1>
                    <p className="text-sm font-sans text-bg-cream/90 font-light max-w-lg mx-auto">
                      {activeCollection?.tagline}
                    </p>
                  </div>
                </section>

                {/* Back button and Editorial Intro */}
                <section className="max-w-4xl mx-auto px-4 text-center space-y-6">
                  <button
                    onClick={() => setSelectedCollectionId(null)}
                    className="text-[11px] font-mono uppercase tracking-widest text-text-muted hover:text-text-charcoal transition-colors mb-4 focus:outline-none"
                  >
                    ← Quay lại Danh sách Dòng sản phẩm
                  </button>
                  <p className="font-serif text-2xl font-light text-text-charcoal italic leading-relaxed">
                    "{activeCollection?.introduction}"
                  </p>
                  <div className="w-12 h-[1px] bg-border-bone mx-auto"></div>
                  <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed max-w-2xl mx-auto">
                    {activeCollection?.description} Quy trình bào chế chậm của chúng tôi chiết tách các hoạt chất này dưới nhiệt độ được kiểm soát chân không nghiêm ngặt để đảm bảo không bị suy thoái nhiệt.
                  </p>
                </section>

                {/* Specific Product Grid */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
                  <div className="text-center">
                    <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-text-muted block">
                      Sản phẩm Thảo mộc Bản địa
                    </span>
                    <h3 className="font-serif text-2xl font-light text-text-charcoal">
                      Công Thức Thảo Mộc Hoàn Thiện
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-4xl mx-auto">
                    {products
                      .filter((p) => p.collectionId === selectedCollectionId)
                      .map((prod) => (
                        <ProductCard
                          key={prod.id}
                          product={prod}
                          onViewDetails={handleViewProduct}
                          onAddToCart={(p, e) => handleAddToCart(p, e)}
                          collectionName={activeCollection?.name || ''}
                          collectionColor={activeCollection?.colorTheme || 'blue'}
                        />
                      ))}
                  </div>
                </section>

                {/* Highlighted Ingredients spécifique to this collection */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
                  <div className="text-center space-y-2">
                    <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-text-muted block">
                      Hoạt Chất Sinh Học
                    </span>
                    <h3 className="font-serif text-2xl font-light text-text-charcoal">
                      Mẫu Thảo Mộc Chủ Đạo
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                    {ingredients
                      .filter((ing) => ing.collections.includes(selectedCollectionId || ''))
                      .map((ing) => (
                        <div 
                          key={ing.id}
                          onClick={() => {
                            setCurrentPage('ingredients');
                            setSelectedIngredientId(ing.id);
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          className="flex items-start space-x-6 bg-bg-beige/25 p-6 border border-border-bone/60 hover:border-border-bone transition-all duration-300 cursor-pointer"
                        >
                          <img
                            src={ing.image}
                            alt={ing.name}
                            referrerPolicy="no-referrer"
                            className="w-20 h-20 rounded-full object-cover bg-bg-beige border border-border-bone/40 shrink-0"
                          />
                          <div className="space-y-1.5">
                            <span className="text-[9px] font-mono text-text-muted uppercase">Mẫu vật Đặc trưng</span>
                            <h4 className="font-serif text-lg font-medium text-text-charcoal">{ing.name}</h4>
                            <p className="text-xs text-text-muted font-light line-clamp-2 leading-relaxed">
                              {ing.poeticIntro}
                            </p>
                          </div>
                        </div>
                      ))}
                  </div>
                </section>

                {/* Benefits specs list */}
                <section className="bg-bg-beige/40 py-16 border-y border-border-bone/60">
                  <div className="max-w-4xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                    <div className="space-y-2">
                      <h4 className="font-serif text-lg font-medium text-text-charcoal">Kích hoạt Tế bào</h4>
                      <p className="text-xs text-text-muted font-light leading-relaxed">
                        Được bào chế tương thích hoàn hảo với độ mặn ẩm tự nhiên của các lớp biểu bì khỏe mạnh.
                      </p>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-serif text-lg font-medium text-text-charcoal">Bảo tồn Tinh khiết</h4>
                      <p className="text-xs text-text-muted font-light leading-relaxed">
                        Đóng gói trong thủy tinh hổ phách tối cản sáng để ngăn chặn quá trình oxy hóa lipid từ tia cực tím.
                      </p>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-serif text-lg font-medium text-text-charcoal">Vận chuyển Thân thiện</h4>
                      <p className="text-xs text-text-muted font-light leading-relaxed">
                        Đến tay bạn được đóng gói trọn vẹn trong lá thô tự nhiên và dây gai mộc mạc.
                      </p>
                    </div>
                  </div>
                </section>

                {/* Lifestyle Image closing element */}
                <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
                  <div className="aspect-[21/9] bg-bg-beige overflow-hidden border border-border-bone/40">
                    <img
                      src="https://images.unsplash.com/photo-1471193945509-9ad0617afabf?q=80&w=1200&auto=format&fit=crop"
                      alt="Organic meadow details"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover brightness-[0.95]"
                    />
                  </div>
                </section>

              </div>
            )}

          </div>
        )}

        {/* ========================================================= */}
        {/* PAGE: INGREDIENT LIBRARY */}
        {/* ========================================================= */}
        {currentPage === 'ingredients' && (
          <div className="animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
            
            {/* Header */}
            <section className="max-w-3xl mx-auto text-center space-y-4">
              <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-brand-yellow block">
                Danh mục Hoạt chất
              </span>
              <h1 className="font-serif text-4xl sm:text-5xl font-light text-text-charcoal tracking-wide">
                Thư viện Thành phần Thảo mộc
              </h1>
              <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed">
                Minh bạch tuyệt đối không qua bộ lọc hóa học. Khám phá các chiết xuất từ đất và bờ biển thô mộc được bào chế trong các dòng sản phẩm Nước (Xanh dương), Mặt trời (Vàng), và Đất sét (Đỏ) của chúng tôi.
              </p>

              {/* Directory Filter tabs */}
              <div className="flex items-center justify-center space-x-4 pt-6">
                {[
                  { id: 'all', label: 'Tất cả các dòng' },
                  { id: 'metabi', label: 'Dòng Nước (Xanh)' },
                  { id: 'candles', label: 'Dòng Mật ong (Vàng)' },
                  { id: 'soaps', label: 'Dòng Đất sét (Đỏ)' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setIngredientFilter(tab.id);
                      setSelectedIngredientId(null);
                    }}
                    className={`px-4 py-2 border text-[11px] font-mono uppercase tracking-wider transition-all duration-200 cursor-pointer ${
                      ingredientFilter === tab.id
                        ? 'border-text-charcoal bg-text-charcoal text-bg-cream'
                        : 'border-border-bone text-text-muted hover:border-text-muted'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </section>

            {/* If an ingredient is selected, show detail layout. Otherwise show directory grid. */}
            {selectedIngredientId && activeIngredient ? (
              <section className="max-w-4xl mx-auto bg-bg-beige/10 border border-border-bone p-6 sm:p-12 space-y-12 animate-fade-in">
                
                {/* Detail Header & Close */}
                <div className="flex items-center justify-between border-b border-border-bone pb-6">
                  <button
                    onClick={() => setSelectedIngredientId(null)}
                    className="text-[10px] font-mono uppercase tracking-widest text-text-muted hover:text-text-charcoal focus:outline-none"
                  >
                    ← Quay lại Thư mục Thư viện
                  </button>
                  <span className="text-[10px] font-mono uppercase text-brand-blue font-semibold">
                    Mã số Mẫu vật #{activeIngredient.id.toUpperCase()}
                  </span>
                </div>

                {/* Title and image block */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                  <div className="space-y-4">
                    <span className="text-[10px] font-mono text-brand-red uppercase tracking-wider block">Chiết xuất Hoạt tính</span>
                    <h2 className="font-serif text-3xl sm:text-4xl font-light text-text-charcoal leading-tight">
                      {activeIngredient.name}
                    </h2>
                    <p className="text-xs font-mono text-text-muted italic">
                      Lớp Thực vật: {activeIngredient.botanicalName}
                    </p>
                    <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed">
                      {activeIngredient.poeticIntro}
                    </p>
                  </div>
                  <div className="aspect-square bg-bg-beige rounded-full overflow-hidden border border-border-bone/40 max-w-[280px] mx-auto md:mr-0">
                    <img
                      src={activeIngredient.image}
                      alt={activeIngredient.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover brightness-[0.95]"
                    />
                  </div>
                </div>

                {/* Geographical Origin region */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8 border-t border-border-bone">
                  <div className="space-y-4">
                    <h3 className="font-serif text-xl font-medium text-text-charcoal">Nguồn gốc Địa lý</h3>
                    <p className="text-xs text-text-muted font-light leading-relaxed">
                      {activeIngredient.originText}
                    </p>
                  </div>
                  <div className="aspect-[16/10] bg-bg-beige overflow-hidden border border-border-bone/40">
                    <img
                      src={activeIngredient.originImage}
                      alt="Origin Region Map context"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover filter brightness-[0.9]"
                    />
                  </div>
                </div>

                {/* Benefit checklist items */}
                <div className="space-y-4 pt-8 border-t border-border-bone">
                  <h3 className="font-serif text-xl font-medium text-text-charcoal">Lợi ích Tế bào Hoạt tính</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                    {activeIngredient.benefits.map((benefit, idx) => (
                      <div key={idx} className="flex items-start space-x-3 bg-bg-cream border border-border-bone/50 p-4 rounded">
                        <Check size={14} className="text-brand-blue shrink-0 mt-0.5" />
                        <span className="text-xs text-text-charcoal font-light leading-relaxed">{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Used In Products mapping */}
                <div className="space-y-4 pt-8 border-t border-border-bone">
                  <h3 className="font-serif text-xl font-medium text-text-charcoal">Sử dụng trong Công thức</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {products
                      .filter((p) => activeIngredient.collections.includes(p.collectionId))
                      .map((p) => (
                        <div 
                          key={p.id}
                          onClick={() => handleViewProduct(p)}
                          className="bg-bg-cream hover:bg-bg-beige border border-border-bone/60 p-4 text-center cursor-pointer transition-all rounded"
                        >
                          <img
                            src={p.image}
                            alt={p.name}
                            referrerPolicy="no-referrer"
                            className="w-12 h-14 object-cover mx-auto mb-2 bg-bg-beige border border-border-bone/30"
                          />
                          <h4 className="font-serif text-[11px] font-medium text-text-charcoal line-clamp-2 leading-tight">
                            {p.name}
                          </h4>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Scientific citations */}
                {activeIngredient.scientificReferences && (
                  <div className="pt-8 border-t border-border-bone space-y-3">
                    <span className="text-[9px] font-mono text-text-muted uppercase tracking-wider block">
                      Trích dẫn Thư mục Khoa học
                    </span>
                    <ul className="space-y-1 text-[11px] font-mono text-text-muted/80 list-disc list-inside">
                      {activeIngredient.scientificReferences.map((ref, idx) => (
                        <li key={idx}>{ref}</li>
                      ))}
                    </ul>
                  </div>
                )}

              </section>
            ) : (
              
              /* Directory Grid view */
              <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {ingredients
                  .filter((ing) => {
                    if (ingredientFilter === 'all') return true;
                    return ing.collections.includes(ingredientFilter);
                  })
                  .map((ing) => (
                    <div 
                      key={ing.id}
                      onClick={() => handleViewIngredient(ing)}
                      className="group bg-bg-beige/15 hover:bg-bg-beige/40 border border-border-bone/60 hover:border-border-bone p-6 text-center space-y-4 transition-all duration-300 cursor-pointer"
                    >
                      <div className="w-24 h-24 rounded-full overflow-hidden mx-auto bg-bg-beige border border-border-bone/40">
                        <img
                          src={ing.image}
                          alt={ing.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                      </div>
                      <div>
                        <h4 className="font-serif text-base font-medium text-text-charcoal group-hover:text-brand-blue transition-colors">
                          {ing.name}
                        </h4>
                        <span className="text-[10px] font-mono text-text-muted italic block mt-1">
                          {ing.botanicalName}
                        </span>
                      </div>
                      <p className="text-xs text-text-muted font-light line-clamp-3 leading-relaxed">
                        {ing.poeticIntro}
                      </p>
                      <span className="inline-block text-[10px] font-mono text-brand-blue uppercase tracking-widest pt-2 group-hover:underline">
                        Khảo sát Mẫu vật →
                      </span>
                    </div>
                  ))}
              </section>
            )}

          </div>
        )}

        {/* ========================================================= */}
        {/* PAGE: PRODUCT DETAIL PAGE */}
        {/* ========================================================= */}
        {currentPage === 'product-detail' && activeProduct && (
          <div className="animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-24">
            
            {/* Sticky Split detail view */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
              
              {/* Left Column (60% width): Sticky Gallery */}
              <div className="lg:col-span-7 space-y-4 lg:sticky lg:top-24">
                
                {/* Large viewport Image */}
                <div className="aspect-[4/5] bg-bg-beige overflow-hidden border border-border-bone/60">
                  <img
                    src={productGalleryIndex === 0 ? activeProduct.image : activeProduct.hoverImage}
                    alt={activeProduct.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-opacity duration-300"
                  />
                </div>

                {/* Gallery thumbnail selectors */}
                <div className="flex space-x-3">
                  <button
                    onClick={() => setProductGalleryIndex(0)}
                    className={`w-20 h-24 border bg-bg-beige overflow-hidden cursor-pointer focus:outline-none ${
                      productGalleryIndex === 0 ? 'border-text-charcoal ring-1 ring-text-charcoal' : 'border-border-bone/60'
                    }`}
                  >
                    <img src={activeProduct.image} alt="Angle primary" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </button>
                  <button
                    onClick={() => setProductGalleryIndex(1)}
                    className={`w-20 h-24 border bg-bg-beige overflow-hidden cursor-pointer focus:outline-none ${
                      productGalleryIndex === 1 ? 'border-text-charcoal ring-1 ring-text-charcoal' : 'border-border-bone/60'
                    }`}
                  >
                    <img src={activeProduct.hoverImage} alt="Angle secondary" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </button>
                </div>
              </div>

              {/* Right Column (40% width): Scrollable details */}
              <div className="lg:col-span-5 space-y-8">
                
                {/* Title block */}
                <div className="space-y-3 pb-6 border-b border-border-bone">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-text-muted">
                    Dòng sản phẩm: {collections.find(c => c.id === activeProduct.collectionId)?.name}
                  </span>
                  <h1 className="font-serif text-3xl sm:text-4xl font-light text-text-charcoal tracking-wide leading-tight">
                    {activeProduct.name}
                  </h1>
                  <p className="font-mono text-lg font-semibold text-text-charcoal">
                    {activeProduct.price}
                  </p>
                  <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed pt-2">
                    {activeProduct.introduction}
                  </p>
                </div>

                {/* Add to basket trigger */}
                <div>
                  <button
                    onClick={() => handleAddToCart(activeProduct)}
                    className="w-full py-4 bg-brand-blue hover:bg-brand-blue-light text-bg-cream text-xs font-mono uppercase tracking-widest transition-colors duration-300 flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <span>Thêm vào Giỏ thảo mộc</span>
                  </button>
                  <p className="text-[10px] font-mono text-text-muted text-center mt-2 uppercase tracking-wider">
                    🎁 Đóng gói bằng lá khuynh diệp tươi & dây gai mộc mạc
                  </p>
                </div>

                {/* Interactive Specs tabs */}
                <div className="space-y-4">
                  <div className="flex border-b border-border-bone">
                    {[
                      { id: 'benefits', label: 'Công dụng cho Da' },
                      { id: 'ingredients', label: 'Thành phần đầy đủ' },
                      { id: 'howtouse', label: 'Nghi thức Sử dụng' },
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveProductTab(tab.id as any)}
                        className={`flex-1 text-center py-2 text-[10px] font-mono uppercase tracking-wider focus:outline-none border-b-2 cursor-pointer transition-colors ${
                          activeProductTab === tab.id
                            ? 'border-text-charcoal text-text-charcoal font-medium'
                            : 'border-transparent text-text-muted'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>

                  <div className="min-h-[140px] py-2">
                    {activeProductTab === 'benefits' && (
                      <ul className="space-y-2">
                        {activeProduct.benefits.map((benefit, idx) => (
                          <li key={idx} className="flex items-start space-x-2 text-xs text-text-muted font-light leading-relaxed">
                            <span className="text-brand-blue shrink-0 mt-0.5">●</span>
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    )}

                    {activeProductTab === 'ingredients' && (
                      <div className="space-y-3">
                        <p className="text-xs text-text-muted/80 font-mono leading-relaxed bg-bg-beige/25 p-3 border border-border-bone/40">
                          {activeProduct.fullIngredients.join(', ')}
                        </p>
                        <p className="text-[10px] font-mono text-text-muted uppercase tracking-wider">
                          🧪 Ma trận sinh học nhũ hóa lạnh 100%, không chứa chất độn.
                        </p>
                      </div>
                    )}

                    {activeProductTab === 'howtouse' && (
                      <ol className="space-y-3">
                        {activeProduct.usageSteps.map((step, idx) => (
                          <li key={idx} className="flex space-x-2 text-xs text-text-muted font-light leading-relaxed">
                            <span className="font-mono text-xs text-brand-red font-medium">{idx + 1}.</span>
                            <span>{step}</span>
                          </li>
                        ))}
                      </ol>
                    )}
                  </div>
                </div>

                {/* Texture/Fragrance & suitability blocks */}
                <div className="grid grid-cols-2 gap-4 pt-6 border-t border-border-bone">
                  <div className="space-y-1.5">
                    <span className="text-[9px] font-mono uppercase tracking-wider text-text-muted block">Hồ sơ Cảm quan</span>
                    <p className="text-xs text-text-charcoal font-medium">{activeProduct.texture}</p>
                    <p className="text-[11px] text-text-muted italic leading-tight">{activeProduct.fragrance}</p>
                  </div>
                  <div className="space-y-1.5">
                    <span className="text-[9px] font-mono uppercase tracking-wider text-text-muted block">Loại da Tương thích</span>
                    <div className="flex flex-wrap gap-1">
                      {activeProduct.suitableFor.map((skin, idx) => (
                        <span key={idx} className="text-[9px] font-mono bg-bg-beige/60 text-text-charcoal px-2 py-0.5 border border-border-bone/40">
                          {skin}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

              </div>

            </section>

            {/* FAQs Accordion specific to this product */}
            <section className="max-w-3xl mx-auto space-y-6 pt-12 border-t border-border-bone">
              <div className="text-center">
                <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-text-muted block">
                  Hướng dẫn Trước khi Mua
                </span>
                <h3 className="font-serif text-2xl font-light text-text-charcoal">
                  Câu hỏi thường gặp về Công thức & Chăm sóc
                </h3>
              </div>

              <div className="space-y-4">
                {activeProduct.faq.map((faq, idx) => {
                  const isOpen = activeFaqIndex === idx;
                  return (
                    <div key={idx} className="border-b border-border-bone/80 pb-4">
                      <button
                        onClick={() => setActiveFaqIndex(isOpen ? null : idx)}
                        className="w-full flex items-center justify-between text-left py-2 font-serif text-base text-text-charcoal hover:text-brand-blue focus:outline-none cursor-pointer"
                      >
                        <span>{faq.question}</span>
                        <span>{isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}</span>
                      </button>
                      {isOpen && (
                        <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed mt-2 pl-2 border-l border-brand-blue animate-fade-in">
                          {faq.answer}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Related Products within collection */}
            <section className="space-y-8 pt-12 border-t border-border-bone">
              <div className="text-center">
                <span className="text-[10px] font-mono uppercase tracking-widest text-text-muted">
                  Sự Kết hợp Thảo mộc
                </span>
                <h3 className="font-serif text-2xl font-light text-text-charcoal mt-1">
                  Công thức Dòng liên quan
                </h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
                {products
                  .filter((p) => p.id !== activeProduct.id && p.collectionId === activeProduct.collectionId)
                  .map((p) => {
                    const col = collections.find(c => c.id === p.collectionId);
                    return (
                      <ProductCard
                        key={p.id}
                        product={p}
                        onViewDetails={handleViewProduct}
                        onAddToCart={(prod, e) => handleAddToCart(prod, e)}
                        collectionName={col?.name || ''}
                        collectionColor={col?.colorTheme || 'blue'}
                      />
                    );
                  })}
              </div>
            </section>

          </div>
        )}

        {/* ========================================================= */}
        {/* PAGE: JOURNAL (SLOW LITERATURE) */}
        {/* ========================================================= */}
        {currentPage === 'journal' && (
          <div className="animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
            
            {/* Header */}
            <section className="max-w-3xl mx-auto text-center space-y-4">
              <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-brand-blue block">
                Tin tức Thảo mộc
              </span>
              <h1 className="font-serif text-4xl sm:text-5xl font-light text-text-charcoal tracking-wide">
                Ký sự Sống Chậm
              </h1>
              <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed">
                Các tiểu luận về chu kỳ thu hoạch theo mùa, hóa học đất sét cấu trúc, và triết lý trị liệu của thói quen vệ sinh không vội vã.
              </p>

              {/* Category tabs */}
              <div className="flex items-center justify-center space-x-6 pt-6">
                {[
                  { id: 'all', label: 'Tất cả Ký sự' },
                  { id: 'Rituals', label: 'Nghi thức' },
                  { id: 'Ingredients', label: 'Thành phần' },
                  { id: 'Craftsmanship', label: 'Chế tác' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setJournalFilter(tab.id)}
                    className={`text-xs uppercase font-mono tracking-widest pb-1 border-b-2 cursor-pointer focus:outline-none transition-colors ${
                      journalFilter === tab.id
                        ? 'border-text-charcoal text-text-charcoal font-medium'
                        : 'border-transparent text-text-muted hover:text-text-charcoal'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </section>

            {/* Articles Grid */}
            <section className="grid grid-cols-1 md:grid-cols-3 gap-10">
              {journalArticles
                .filter((art) => {
                  if (journalFilter === 'all') return true;
                  return art.category === journalFilter;
                })
                .map((art) => (
                  <div 
                    key={art.id}
                    onClick={() => handleViewArticle(art)}
                    className="group flex flex-col space-y-4 cursor-pointer"
                  >
                    <div className="aspect-[4/5] bg-bg-beige overflow-hidden border border-border-bone/40">
                      <img
                        src={art.image}
                        alt={art.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.02] filter brightness-[0.93]"
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-[10px] font-mono text-text-muted uppercase tracking-wider">
                        <span>{art.category === 'Rituals' ? 'Nghi thức' : art.category === 'Ingredients' ? 'Thành phần' : art.category === 'Craftsmanship' ? 'Chế tác' : art.category}</span>
                        <span>·</span>
                        <span>{art.readTime}</span>
                      </div>
                      <h4 className="font-serif text-lg font-medium text-text-charcoal group-hover:text-brand-blue transition-colors leading-snug">
                        {art.title}
                      </h4>
                      <p className="text-xs text-text-muted font-light leading-relaxed line-clamp-3">
                        {art.excerpt}
                      </p>
                      <span className="inline-block text-[10px] font-mono text-text-charcoal uppercase tracking-widest pt-2 border-b border-text-charcoal group-hover:text-brand-blue group-hover:border-brand-blue transition-colors">
                        Đọc câu chuyện →
                      </span>
                    </div>
                  </div>
                ))}
            </section>

          </div>
        )}

        {/* ========================================================= */}
        {/* PAGE: ARTICLE DETAIL (READER INTERFACE) */}
        {/* ========================================================= */}
        {currentPage === 'article-detail' && activeArticle && (
          <article className="animate-fade-in max-w-3xl mx-auto px-4 py-12 space-y-8">
            
            {/* Header / Meta */}
            <div className="space-y-4 text-center">
              <button
                onClick={() => setCurrentPage('journal')}
                className="text-[10px] font-mono uppercase tracking-widest text-text-muted hover:text-text-charcoal focus:outline-none mb-4"
              >
                ← Quay lại danh sách Ký sự
              </button>
              <div className="flex items-center justify-center space-x-3 text-xs font-mono text-text-muted uppercase tracking-widest">
                <span>{activeArticle.category === 'Rituals' ? 'Nghi thức' : activeArticle.category === 'Ingredients' ? 'Thành phần' : activeArticle.category === 'Craftsmanship' ? 'Chế tác' : activeArticle.category}</span>
                <span>·</span>
                <span>{activeArticle.readTime}</span>
              </div>
              <h1 className="font-serif text-3xl sm:text-5xl font-light text-text-charcoal tracking-wide leading-tight">
                {activeArticle.title}
              </h1>
              <p className="text-sm font-sans text-text-muted italic max-w-xl mx-auto pt-2">
                "{activeArticle.excerpt}"
              </p>

              {/* Author / Date info */}
              <div className="flex items-center justify-center space-x-3 pt-4 border-y border-border-bone/60 py-3 text-xs font-mono text-text-muted">
                <span className="flex items-center space-x-1">
                  <User size={12} />
                  <span>Bởi {activeArticle.author}</span>
                </span>
                <span>·</span>
                <span className="flex items-center space-x-1">
                  <Calendar size={12} />
                  <span>{activeArticle.date}</span>
                </span>
              </div>
            </div>

            {/* Featured Image */}
            <div className="aspect-[16/9] bg-bg-beige overflow-hidden border border-border-bone/40 my-8">
              <img
                src={activeArticle.image}
                alt={activeArticle.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover brightness-[0.95]"
              />
            </div>

            {/* Editorial Serif Paragraphs content */}
            <div className="font-serif text-base sm:text-lg text-text-charcoal/90 leading-relaxed space-y-6 pt-4">
              <p>{activeArticle.content}</p>
              <p className="text-xs sm:text-sm text-text-muted font-sans font-light italic border-l-2 border-brand-yellow pl-4 py-1">
                "Phòng thí nghiệm của chúng tôi tại các vùng rừng phía bắc tin rằng vẻ đẹp tế bào cần có những chu kỳ thay mới tự nhiên. Chúng tôi nghiên cứu và bào chế sử dụng các enzym thực vật sống để hỗ trợ nhịp điệu sinh học này."
              </p>
              <p>
                Khi bạn kết hợp các chế phẩm này vào việc vệ sinh hàng ngày, hãy dành ba mươi giây để cảm nhận kết cấu sản phẩm. Sự cọ xát của những thanh bùn xà phòng cắt tay, làn sương mát lạnh của nước khoáng, sự ấm áp mượt mà của dầu hoa. Những chi tiết này không phải là sự phù phiếm — chúng là những điểm neo tinh thần.
              </p>
            </div>

            {/* Article Footer Sign-off */}
            <div className="pt-12 border-t border-border-bone flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
              <span className="text-xs font-mono text-text-muted uppercase tracking-wide">
                Ban biên tập AVAPHAR Tập VI · Phát hành Toàn cầu
              </span>
              <button
                onClick={() => {
                  setCurrentPage('collections');
                  setSelectedCollectionId(null);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-6 py-3 bg-brand-blue hover:bg-brand-blue-light text-bg-cream text-xs font-mono uppercase tracking-widest transition-colors duration-300"
              >
                Mua dòng sản phẩm Thảo mộc
              </button>
            </div>

          </article>
        )}

        {/* ========================================================= */}
        {/* PAGE: CONTACT */}
        {/* ========================================================= */}
        {currentPage === 'contact' && (
          <div className="animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-24">
            
            {/* Header */}
            <section className="max-w-3xl mx-auto text-center space-y-4">
              <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-brand-red block">
                Không gian Cảm quan
              </span>
              <h1 className="font-serif text-4xl sm:text-5xl font-light text-text-charcoal tracking-wide">
                Yêu cầu Tư vấn & Cửa hàng Trưng bày
              </h1>
              <p className="text-xs sm:text-sm text-text-muted font-light leading-relaxed">
                Liên hệ trực tiếp với văn phòng phòng thí nghiệm của chúng tôi hoặc khám phá các đối tác bán lẻ trưng bày dòng sản phẩm Nước, Mặt trời và Đất sét.
              </p>
            </section>

            {/* Split Contact Info & Form */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-start">
              
              {/* Information Left (5 columns) */}
              <div className="lg:col-span-5 space-y-8 bg-bg-beige/25 p-8 border border-border-bone/80">
                <div className="space-y-2">
                  <span className="text-[10px] font-mono uppercase text-text-muted block">Trụ sở Phòng Thí Nghiệm</span>
                  <h3 className="font-serif text-2xl font-light text-text-charcoal">Avaphar Botanical Lab</h3>
                  <p className="text-xs text-text-muted font-light leading-relaxed">
                    Một phòng thí nghiệm lâm nghiệp nơi các loại bùn biển hoạt tính, mật ong rừng hoang dã và các bánh bùn nung thô được nghiên cứu bào chế.
                  </p>
                </div>

                <div className="space-y-4 pt-6 border-t border-border-bone text-xs font-mono text-text-muted leading-relaxed">
                  <div className="flex items-start space-x-3">
                    <MapPin size={16} className="text-brand-blue shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-text-charcoal block">Địa chỉ Không gian Thảo mộc</strong>
                      <span>120 Organic Earth Way, Botanical Hills, NY 10024</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Mail size={16} className="text-brand-yellow shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-text-charcoal block">Yêu cầu Cảm quan</strong>
                      <span>info@avaphar-botanical.com</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Phone size={16} className="text-brand-red shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-text-charcoal block">Hotline Không gian</strong>
                      <span>+1 (800) 459-SLO-BEAUTY</span>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-border-bone space-y-2">
                  <span className="text-[10px] font-mono uppercase text-text-muted block">Giờ hoạt động</span>
                  <p className="text-xs text-text-charcoal font-light leading-relaxed">
                    Chúng tôi đón tiếp khách ghé thăm theo lịch hẹn trước để đảm bảo chu trình nghiên cứu tinh khiết.<br />
                    Thứ Hai – Thứ Sáu: 10:00 AM – 4:00 PM EST
                  </p>
                </div>
              </div>

              {/* Form Right (7 columns) */}
              <div className="lg:col-span-7 space-y-6">
                {contactSubmitted ? (
                  <div className="p-8 bg-brand-blue/5 border border-brand-blue/20 text-brand-blue animate-fade-in space-y-3 rounded">
                    <Check size={24} />
                    <h4 className="font-serif text-lg font-medium">Yêu cầu Cảm quan đã được Gửi đi</h4>
                    <p className="text-xs text-text-muted leading-relaxed">
                      Cảm ơn bạn. Chúng tôi đọc từng thư yêu cầu một cách cẩn trọng trong buổi họp chiều giữa rừng. Đại diện phòng thí nghiệm sẽ phản hồi bạn trong vòng 24 giờ.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleContactSubmit} className="space-y-6">
                    <div>
                      <h4 className="font-serif text-xl font-medium text-text-charcoal mb-1">Gửi Thư Yêu Cầu Cảm Quan</h4>
                      <p className="text-xs text-text-muted font-light">
                        Hãy để lại thông tin của bạn bên dưới. Chúng tôi phản hồi bằng ngôn ngữ chân thực, mộc mạc và hoàn toàn do con người viết.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-[11px] font-mono uppercase tracking-wider text-text-muted mb-1.5">
                          Tên của bạn
                        </label>
                        <input
                          type="text"
                          required
                          value={contactName}
                          onChange={(e) => setContactName(e.target.value)}
                          className="w-full bg-transparent border-b border-border-bone py-2 text-sm text-text-charcoal focus:outline-none focus:border-brand-blue transition-colors font-sans"
                          placeholder="Evelyn Sterling"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-mono uppercase tracking-wider text-text-muted mb-1.5">
                          Địa chỉ Email
                        </label>
                        <input
                          type="type"
                          required
                          value={contactEmail}
                          onChange={(e) => setContactEmail(e.target.value)}
                          className="w-full bg-transparent border-b border-border-bone py-2 text-sm text-text-charcoal focus:outline-none focus:border-brand-blue transition-colors font-sans"
                          placeholder="sterling@slowbeauty.com"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-mono uppercase tracking-wider text-text-muted mb-1.5">
                        Yêu cầu hoặc Thắc mắc Thảo mộc
                      </label>
                      <textarea
                        required
                        rows={4}
                        value={contactMessage}
                        onChange={(e) => setContactMessage(e.target.value)}
                        className="w-full bg-transparent border-b border-border-bone py-2 text-sm text-text-charcoal focus:outline-none focus:border-brand-blue transition-colors font-sans resize-none"
                        placeholder="Yêu cầu thông tin về chu kỳ thu hoạch, độ tương thích của da, hoặc các đối tác bán lẻ..."
                      />
                    </div>

                    <button
                      type="submit"
                      className="px-8 py-4 bg-brand-blue hover:bg-brand-blue-light text-bg-cream text-xs font-mono uppercase tracking-widest transition-colors duration-300"
                    >
                      Gửi Thư Yêu Cầu
                    </button>
                  </form>
                )}
              </div>

            </section>

            {/* Stockists Partner Grid */}
            <section className="space-y-8 pt-12 border-t border-border-bone">
              <div className="text-center space-y-2">
                <span className="text-[10px] font-mono uppercase tracking-widest text-text-muted">
                  Không gian Trưng bày Thực tế
                </span>
                <h3 className="font-serif text-3xl font-light text-text-charcoal">
                  Các Đối Tác Bán Lẻ Được Tuyển Chọn
                </h3>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                <div className="p-6 bg-bg-beige/10 border border-border-bone/60 rounded text-center space-y-2">
                  <span className="text-[10px] font-mono text-brand-blue font-medium block">Không gian New York</span>
                  <h4 className="font-serif text-base font-medium text-text-charcoal">The Assembly Gallery</h4>
                  <p className="text-[11px] text-text-muted font-light leading-relaxed">
                    SOHO High Street, NYC
                  </p>
                </div>
                <div className="p-6 bg-bg-beige/10 border border-border-bone/60 rounded text-center space-y-2">
                  <span className="text-[10px] font-mono text-brand-yellow font-medium block">Phòng trưng bày Portland</span>
                  <h4 className="font-serif text-base font-medium text-text-charcoal">Timber & Flora Lab</h4>
                  <p className="text-[11px] text-text-muted font-light leading-relaxed">
                    Pearl District, Portland
                  </p>
                </div>
                <div className="p-6 bg-bg-beige/10 border border-border-bone/60 rounded text-center space-y-2">
                  <span className="text-[10px] font-mono text-brand-red font-medium block">Cửa hàng trưng bày Tokyo</span>
                  <h4 className="font-serif text-base font-medium text-text-charcoal">Hinoki Organic Specimen</h4>
                  <p className="text-[11px] text-text-muted font-light leading-relaxed">
                    Meguro-ku, Tokyo, JP
                  </p>
                </div>
                <div className="p-6 bg-bg-beige/10 border border-border-bone/60 rounded text-center space-y-2">
                  <span className="text-[10px] font-mono text-text-muted font-medium block">Phòng trưng bày Copenhagen</span>
                  <h4 className="font-serif text-base font-medium text-text-charcoal">Slow Living Archive</h4>
                  <p className="text-[11px] text-text-muted font-light leading-relaxed">
                    Nørrebrogade, Copenhagen
                  </p>
                </div>
              </div>
            </section>

          </div>
        )}

      </main>

      {/* FOOTER COMPONENT */}
      <Footer 
        onPageChange={setCurrentPage}
        onSelectCollection={setSelectedCollectionId}
      />

      {/* SHOPPING BASKET SIDEBAR */}
      <CartSidebar
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

    </div>
  );
}
