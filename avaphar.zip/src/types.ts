export interface Product {
  id: string;
  name: string;
  collectionId: string;
  price: string;
  image: string;
  hoverImage: string;
  introduction: string;
  benefits: string[];
  fullIngredients: string[];
  usageSteps: string[];
  texture: string;
  fragrance: string;
  suitableFor: string[];
  faq: { question: string; answer: string }[];
  isFeatured?: boolean;
}

export interface Collection {
  id: string;
  name: string;
  tagline: string;
  introduction: string;
  description: string;
  image: string;
  colorTheme: 'blue' | 'yellow' | 'red';
  accentColor: string;
  accentLight: string;
}

export interface Ingredient {
  id: string;
  name: string;
  botanicalName: string;
  poeticIntro: string;
  originText: string;
  originImage: string;
  benefits: string[];
  image: string;
  collections: string[];
  scientificReferences?: string[];
}

export interface JournalArticle {
  id: string;
  category: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  readTime: string;
  image: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
