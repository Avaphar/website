import { Product, Collection, Ingredient, JournalArticle } from './types';

export const collections: Collection[] = [
  {
    id: 'metabi',
    name: 'METABI Marine',
    tagline: 'Khoáng chất sinh học biển sâu',
    introduction: 'Nghi thức cấp ẩm chuyên sâu được bào chế từ sinh vật phù du biển, men bùn đại dương và tảo bẹ hoang dã để phục hồi độ ẩm cho tế bào.',
    description: 'Dòng sản phẩm màu xanh đại diện cho Nước. Được bào chế từ nguồn nước đại dương giàu khoáng chất, chiết xuất tảo bẹ và hoạt chất sinh học biển bảo vệ da, đem lại độ ẩm sâu và mỏng nhẹ.',
    image: 'https://cdn.stocksnap.io/img-thumbs/960w/ocean-wave_XSWSE5GPTK.jpg',
    colorTheme: 'blue',
    accentColor: 'brand-blue',
    accentLight: 'brand-blue-light'
  },
  {
    id: 'candles',
    name: 'Solar Honey & Amber',
    tagline: 'Sắc xuân ấm áp của mặt trời',
    introduction: 'Bộ sưu tập đánh thức giác quan gồm nến sáp đậu nành hữu cơ và dầu dưỡng thể thảo mộc chiết xuất mật ong hoang dã, nhựa hổ phách ấm áp và mật hoa bồ công anh.',
    description: 'Dòng sản phẩm màu vàng đại diện cho Ánh Dương & Sự Ấm Áp. Khai thác mật ong lên men tự nhiên, chiết xuất thảo mộc đón nắng và tinh dầu thiên nhiên giúp xoa dịu tâm hồn.',
    image: 'https://images.unsplash.com/photo-1603006905003-be475563bc59?q=80&w=1000&auto=format&fit=crop',
    colorTheme: 'yellow',
    accentColor: 'brand-yellow',
    accentLight: 'brand-yellow-light'
  },
  {
    id: 'soaps',
    name: 'Cà Phê',
    tagline: 'Tinh lọc khoáng chất từ đất mẹ',
    introduction: 'Nghi thức làm sạch ép lạnh truyền thống từ đất sét nung giàu khoáng chất, bùn hồng Pháp và dầu hạt tầm xuân thu hoạch tự nhiên.',
    description: 'Dòng sản phẩm màu đỏ đại diện cho Đất & Đất Sét. Kết hợp phù sa giàu sắt, đất sét nung nghiền mịn và lipid thực vật ép lạnh cho trải nghiệm làm sạch sâu đầy thư thái.',
    image: '/coffee_cherries.jpg',
    colorTheme: 'red',
    accentColor: 'brand-red',
    accentLight: 'brand-red-light'
  }
];

export const products: Product[] = [
  {
    id: 'metabi-serum',
    name: 'METABI Deep Hydrating Serum',
    collectionId: 'metabi',
    price: '$68',
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=800&auto=format&fit=crop',
    hoverImage: 'https://images.unsplash.com/photo-1608248597481-496100c80836?q=80&w=800&auto=format&fit=crop',
    introduction: 'Sự kết hợp đậm đặc giữa sinh vật phù du vùng Bắc Cực và tảo bẹ khổng lồ hoang dã, hòa quyện trong nước biển đại dương mang lại độ ẩm sâu, đa tầng tế bào.',
    benefits: [
      'Làm căng mọng cấu trúc tế bào da với độ ẩm duy trì liên tục',
      'Bảo vệ màng ẩm của da trước thời tiết lạnh và bụi mịn đô thị',
      'Khôi phục vẻ rạng rỡ tự nhiên thuần khiết và bề mặt mềm mại như nhung'
    ],
    fullIngredients: [
      'Maris Aqua (Nước biển sâu tinh khiết)',
      'Phytoplankton Marinus Extract (Chiết xuất sinh vật phù du)',
      'Macrocystis Pyrifera (Tảo bẹ khổng lồ) Extract',
      'Sodium Hyaluronate (Nguồn gốc thực vật)',
      'Glycerin (Chiết xuất thực vật)',
      'Leuconostoc/Radish Root Ferment Filtrate (Men rễ cải củ)',
      'Laminaria Digitata Extract (Chiết xuất tảo Laminaria)'
    ],
    usageSteps: [
      'Nhỏ 3–4 giọt lên làn da ẩm vừa được xịt khoáng vào buổi sáng và tối.',
      'Vỗ nhẹ nhàng bằng lòng bàn tay lên vùng mặt, cổ và ngực.',
      'Chờ 60 giây để tinh chất thẩm thấu hoàn toàn trước khi thoa dầu dưỡng hoặc kem dưỡng.'
    ],
    texture: 'Gel lỏng mỏng nhẹ',
    fragrance: 'Hương gió biển & Muối dịu mát',
    suitableFor: ['Mọi loại da', 'Da mất nước', 'Da nhạy quan'],
    faq: [
      {
        question: 'Tinh chất METABI có gây bết rít hay nặng mặt không?',
        answer: 'Không. Quy trình ép lạnh tiên tiến của chúng tôi đảm bảo kết cấu gel lỏng tinh khiết, mỏng nhẹ, thẩm thấu ngay lập tức mà không để lại màng dính, hoàn hảo để lót dưới lớp dầu dưỡng hoặc trang điểm.'
      },
      {
        question: 'Tôi có thể sử dụng sản phẩm này hàng ngày không?',
        answer: 'Hoàn toàn có thể. Sản phẩm được bào chế vô cùng dịu nhẹ và giàu dưỡng chất phục hồi, thiết kế tối ưu cho cả sáng và tối hàng ngày.'
      }
    ],
    isFeatured: true
  },
  {
    id: 'metabi-mist',
    name: 'METABI Marine Bio-Essence',
    collectionId: 'metabi',
    price: '$54',
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?q=80&w=800&auto=format&fit=crop',
    hoverImage: 'https://images.unsplash.com/photo-1526947425960-945c6e72858f?q=80&w=800&auto=format&fit=crop',
    introduction: 'Nước xịt dưỡng sinh học đại dương đánh thức làn da với nước khoáng bùn lên men, nguyên tố vi lượng và chiết xuất rêu biển hoang dã.',
    benefits: [
      'Cân bằng độ pH của da ngay tức thì sau khi rửa mặt',
      'Cung cấp làn sương khoáng giàu năng lượng giúp làm bừng sáng làn da mệt mỏi',
      'Đóng vai trò như lớp lót giữ ẩm hoàn hảo cho các bước tinh chất tiếp theo'
    ],
    fullIngredients: [
      'Maris Aqua (Nước khoáng bùn lên men)',
      'Chondrus Crispus (Chiết xuất rêu Ireland)',
      'Aloe Barbadensis Leaf Juice Powder (Bột nha đam hữu cơ)',
      'Saccharomyces/Silicon Ferment',
      'Saccharomyces/Magnesium Ferment',
      'Potassium Sorbate'
    ],
    usageSteps: [
      'Lắc nhẹ. Nhắm mắt và xịt đều khắp vùng mặt và cổ.',
      'Sử dụng ngay sau khi rửa mặt để cân bằng da.',
      'Có thể xịt nhiều lần trong ngày đè lên lớp trang điểm hoặc da mộc để bù nước tức thì.'
    ],
    texture: 'Phun sương siêu mịn',
    fragrance: 'Khí ozone & Rêu ẩm thanh khiết',
    suitableFor: ['Mọi loại da', 'Da xỉn màu', 'Da mệt mỏi'],
    faq: [
      {
        question: 'Đây có phải chỉ là nước biển thông thường không?',
        answer: 'Không. Đây là một loại tinh chất biển được nghiên cứu khoa học tỉ mỉ. Sản phẩm sử dụng nước biển tinh khiết, lên men sinh học với bùn đại dương và chứa dồi dào các chuỗi polysaccharide liên kết nước của rêu biển.'
       }
    ]
  },
  {
    id: 'solar-candle',
    name: 'WILD AMBER Soy Wax Candle',
    collectionId: 'candles',
    price: '$45',
    image: 'https://images.unsplash.com/photo-1508747703725-719ae2c73ee8?q=80&w=800&auto=format&fit=crop',
    hoverImage: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?q=80&w=800&auto=format&fit=crop',
    introduction: 'Nến thơm thực vật cháy chậm, được làm thủ công hoàn toàn từ sáp đậu nành hoang dã kết hợp nhựa hổ phách vàng óng và mật ong rừng nguyên bản.',
    benefits: [
      'Sáp cháy sạch, không tạo muội than lên đến 60 giờ thư giãn',
      'Mang lại không gian ấm áp, rực rỡ và dễ chịu như ánh nắng ban mai',
      'Bấc cotton tự nhiên không chứa chì và hũ thủy tinh hổ phách thủ công có thể tái sử dụng'
    ],
    fullIngredients: [
      '100% Sáp đậu nành hữu cơ, không biến đổi gen',
      'Dầu nhựa hổ phách tự nhiên',
      'Hương mật ong rừng nguyên bản',
      'Tinh dầu Copaiba Balsam',
      'Chiết xuất nguyên chất Vanilla Planifolia'
    ],
    usageSteps: [
      'Trong lần đốt đầu tiên, hãy để sáp tan chảy đều đến sát mép hũ để tránh hiện tượng lõm nến.',
      'Cắt ngắn bấc cotton xuống khoảng 0.6cm trước mỗi lần đốt tiếp theo.',
      'Không đốt nến quá 4 tiếng liên tục và đặt ở nơi không có gió lùa.'
    ],
    texture: 'Sáp đậu nành hữu cơ nguyên khối',
    fragrance: 'Mật ong ấm, Hổ phách ngọt & Vỏ cây',
    suitableFor: ['Liệu pháp mùi hương tại nhà', 'Không gian thiền định', 'Lối sống chánh niệm'],
    faq: [
      {
        question: 'Thời gian cháy của nến là bao lâu?',
        answer: 'Nến Wild Amber cháy sạch trong khoảng 55 đến 60 giờ trong điều kiện tối ưu khi bấc được cắt tỉa đều đặn.'
      },
      {
        question: 'Thương hiệu có sử dụng hương liệu tổng hợp không?',
        answer: 'Không. Chúng tôi chỉ sử dụng nhựa tự nhiên, chiết xuất hoa nguyên chất và mật ong tự nhiên để tạo hương thơm chân thật nhất.'
      }
    ],
    isFeatured: true
  },
  {
    id: 'solar-oil',
    name: 'SOLAR NECTAR Botanical Body Oil',
    collectionId: 'candles',
    price: '$62',
    image: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?q=80&w=800&auto=format&fit=crop',
    hoverImage: 'https://images.unsplash.com/photo-1617897903246-719242758050?q=80&w=800&auto=format&fit=crop',
    introduction: 'Một loại thần dược từ nắng ấm bao bọc cơ thể bạn trong màng sương vàng óng ả của dầu hạt mơ châu Âu, chiết xuất mật ong và dầu yến mạch hữu cơ.',
    benefits: [
      'Mang lại vẻ rạng rỡ, bóng khỏe tự nhiên cho làn da khô ráp',
      'Nuôi dưỡng sâu nhờ chứa các axit béo thiết yếu và Vitamin E tự nhiên',
      'Làm dịu làn da bị kích ứng, mẩn đỏ và vùng da tiếp xúc nhiều với ánh nắng'
    ],
    fullIngredients: [
      'Prunus Armeniaca (Dầu mơ châu Âu) Kernel Oil',
      'Avena Sativa (Dầu yến mạch) Kernel Oil',
      'Lipid mật ong rừng nguyên bản',
      'Spiraea Ulmaria (Chiết xuất cỏ ngọt) Extract',
      'Helianthus Annuus (Dầu hạt hướng dương) Seed Oil',
      'Tocopherol (Vitamin E)'
    ],
    usageSteps: [
      'Massage nhẹ nhàng lên làn da còn ẩm ngay sau khi tắm nước ấm.',
      'Tập trung vào các vùng da khô ráp như khuỷu tay, đầu gối và xương quai xanh.',
      'Chờ vài phút để dầu thẩm thấu hoàn toàn, mang lại lớp finish mềm mại như nhung trước khi mặc quần áo.'
    ],
    texture: 'Dầu vàng mượt như nhung',
    fragrance: 'Yến mạch ấm, Mật ong đón nắng & Cam chanh',
    suitableFor: ['Da khô', 'Da nhạy cảm', 'Làn da rám nắng'],
    faq: [
      {
        question: 'Dầu dưỡng này có gây nhờn dính da không?',
        answer: 'Dù là dòng dầu dưỡng giàu dưỡng chất, nền dầu mơ và yến mạch rất mỏng nhẹ, thẩm thấu cực nhanh khi thoa trên da ẩm và để lại lớp nền satin khô thoáng.'
      }
    ]
  },
  {
    id: 'terracotta-soap',
    name: 'TERRACOTTA Mineral Mud Bar',
    collectionId: 'soaps',
    price: '$28',
    image: 'https://images.unsplash.com/photo-1546554137-f86b9593a222?q=80&w=800&auto=format&fit=crop',
    hoverImage: 'https://images.unsplash.com/photo-1590156221122-c7b390fc1fd0?q=80&w=800&auto=format&fit=crop',
    introduction: 'Bánh bùn khoáng ép thủ công truyền thống chứa đất sét đỏ Terracotta và phù sa núi lửa giàu sắt giúp làm sạch sâu và tẩy tế bào chết dịu nhẹ.',
    benefits: [
      'Hút sạch bụi bẩn siêu vi và dầu thừa nhờ hoạt tính khoáng chất',
      'Bọt thảo mộc dịu nhẹ không làm mất đi màng lipid tự nhiên của da',
      'Tẩy tế bào chết nhẹ nhàng cho làn da mịn màng, mộc mạc'
    ],
    fullIngredients: [
      'Dầu ô liu xà phòng hóa',
      'Dầu dừa xà phòng hóa',
      'Đất sét đỏ đất nung tự nhiên (Argilla)',
      'Chiết xuất bùn khoáng núi lửa giàu sắt',
      'Butyrospermum Parkii (Bơ hạt mỡ)',
      'Melaleuca Alternifolia (Tinh dầu tràm trà)'
    ],
    usageSteps: [
      'Tạo bọt bánh xà phòng giữa hai bàn tay ướt hoặc massage trực tiếp lên cơ thể ẩm.',
      'Để lớp bọt bùn khoáng giàu dưỡng chất lưu lại trên da 30 giây như một mặt nạ thải độc nhỏ.',
      'Rửa sạch hoàn toàn bằng nước ấm và dưỡng ẩm tiếp tục bằng dầu dưỡng thể.'
    ],
    texture: 'Bánh xà phòng đất mịn màng',
    fragrance: 'Đất ẩm ấm áp, Tràm trà & Gỗ đàn hương',
    suitableFor: ['Da dầu', 'Da bít tắc lỗ chân lông', 'Da thường'],
    faq: [
      {
        question: 'Tôi có thể dùng bánh bùn khoáng này cho da mặt không?',
        answer: 'Được. Sản phẩm vô cùng dịu nhẹ và phù hợp cho da mặt dầu hoặc dễ bị bít tắc lỗ chân lông. Tránh tiếp xúc trực tiếp với mắt.'
      },
      {
        question: 'Sản phẩm có dễ bị chảy nước trong nhà tắm không?',
        answer: 'Nhờ công nghệ ép ba lớp truyền thống, bánh xà phòng có độ nén cao và sử dụng lâu hơn 2-3 lần so với xà phòng thủ công thông thường. Nên giữ trên khay thoát nước.'
      }
    ],
    isFeatured: true
  },
  {
    id: 'pink-clay-soap',
    name: 'CLAY ROSE Refining Cleansing Soap',
    collectionId: 'soaps',
    price: '$32',
    image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?q=80&w=800&auto=format&fit=crop',
    hoverImage: 'https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?q=80&w=800&auto=format&fit=crop',
    introduction: 'Bánh xà phòng tắm dưỡng da màu hồng tinh tế được ép lạnh chứa đất sét hồng Pháp, bùn khoáng và dầu hạt tầm xuân hoang dã.',
    benefits: [
      'Se khít lỗ chân lông và làm mịn màng bề mặt da không đều màu',
      'Giàu axit béo thiết yếu bảo vệ sức khỏe của hàng rào bảo vệ da',
      'Mang lại cảm giác sạch thoáng, căng mọng và hương hoa hồng thoang thoảng'
    ],
    fullIngredients: [
      'Dầu quả ô liu xà phòng hóa',
      'Dầu hạt tầm xuân hoang dã xà phòng hóa',
      'Kaolin (Đất sét hồng Pháp)',
      'Rosa Damascena (Nước cất hoa hồng Damask)',
      'Pelargonium Graveolens (Tinh dầu phong lữ)',
      'Aniba Rosodora (Tinh dầu gỗ hồng)'
    ],
    usageSteps: [
      'Tạo bọt mịn với nước ấm để tạo lớp bọt kem sang trọng.',
      'Massage nhẹ nhàng theo chuyển động tròn đều khắp mặt và cổ.',
      'Rửa sạch bằng nước mát để thu nhỏ lỗ chân lông và đánh thức làn da.'
    ],
    texture: 'Bánh xà phòng kem mịn',
    fragrance: 'Hoa hồng Damask & Phong lữ hoang dã',
    suitableFor: ['Da khô', 'Da lão hóa', 'Da nhạy cảm'],
    faq: [
      {
        question: 'Sản phẩm có làm khô căng làn da vốn đã khô của tôi không?',
        answer: 'Khác với xà phòng công nghiệp, bánh xà phòng của chúng tôi giữ lại 100% glycerin thực vật tự nhiên và được bổ sung thêm dầu hạt tầm xuân hoang dã để nuôi dưỡng làn da khô.'
      }
    ]
  }
];

export const ingredients: Ingredient[] = [
  {
    id: 'plankton',
    name: 'Chiết xuất sinh vật phù du biển',
    botanicalName: 'Phytoplankton Marinus',
    poeticIntro: 'Một nguồn năng lượng sống siêu vi được thu hoạch từ những vùng biển sâu tinh khiết nhất, mang theo nguyên bản của cơ chế cấp ẩm tế bào.',
    originText: 'Được khai thác bền vững từ các bồn đại dương nước lạnh ngoài khơi bờ biển phía bắc, sinh vật phù du của chúng tôi được xử lý thô để giữ nguyên vẹn khoáng chất, peptide và axit amin.',
    originImage: 'https://images.unsplash.com/photo-1505118380757-91f5f5632de0?q=80&w=800&auto=format&fit=crop',
    benefits: [
      'Cấp ẩm sâu và duy trì độ ẩm lâu dài cho tế bào da',
      'Tái tạo và củng cố hàng rào lipid mỏng manh của da',
      'Bảo vệ da trước ô nhiễm khói bụi đô thị và các tác nhân oxy hóa'
    ],
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=800&auto=format&fit=crop',
    collections: ['metabi'],
    scientificReferences: [
      'Tạp chí Khoa học Biển & Hoạt chất Sinh học, 2024 (Tập 12, trang 45-51)',
      'Đánh giá Peptide Tảo và Cấp ẩm Quốc tế, Tập 42'
    ]
  },
  {
    id: 'honey',
    name: 'Mật ong rừng & Mật hoa bồ công anh',
    botanicalName: 'Mel & Taraxacum Officinale',
    poeticIntro: 'Thần dược vàng óng được tạo nên bởi loài ong núi hoang dã, lưu giữ những tia nắng ban mai và enzym tự nhiên giúp làm lành và khóa ẩm ưu việt.',
    originText: 'Được thu hoạch từ những đồng cỏ núi cao hoang sơ trong đợt hoa nở rộ giữa mùa hè. Mật ong hoàn toàn không qua lọc và vô cùng giàu chất chống oxy hóa hữu cơ.',
    originImage: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=800&auto=format&fit=crop',
    benefits: [
      'Thuộc tính hút ẩm tự nhiên giúp dẫn truyền nước sâu vào tế bào da',
      'Làm dịu tình trạng viêm da và giảm thiểu mẩn đỏ',
      'Giàu các hợp chất enzym giúp tẩy tế bào chết nhẹ nhàng cho làn da rạng rỡ đón nắng'
    ],
    image: 'https://images.unsplash.com/photo-1471193945509-9ad0617afabf?q=80&w=800&auto=format&fit=crop',
    collections: ['candles'],
    scientificReferences: [
      'Tạp chí Nghiên cứu Nuôi ong & Ứng dụng Da liễu, 2023',
      'Báo cáo Trị liệu Thảo dược Hàng quý, Số 984'
    ]
  },
  {
    id: 'clay',
    name: 'Đất sét khoáng nung Terracotta',
    botanicalName: 'Argilla Terracotta',
    poeticIntro: 'Lớp đất sét giàu sắt được tôi luyện qua hàng thế kỷ dưới sức nóng mặt trời, mang các nguyên tố vi lượng hấp thụ tạp chất siêu vi vô cùng dịu nhẹ.',
    originText: 'Được khai thác nhân văn từ các mỏ đất sét cổ xưa ở thung lũng phía nam đầy nắng, phơi khô tự nhiên dưới gió núi và nghiền mịn thành những hạt siêu nhỏ mịn như lụa.',
    originImage: 'https://images.unsplash.com/photo-1473448912268-2022ce9509d8?q=80&w=800&auto=format&fit=crop',
    benefits: [
      'Hút sạch dầu thừa và kim loại nặng nhờ lực hút từ tính tự nhiên',
      'Làm mịn và cải thiện kết cấu bề mặt da một cách an toàn',
      'Bổ sung lượng magiê, silica và sắt thiết yếu vào lớp biểu bì'
    ],
    image: 'https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?q=80&w=800&auto=format&fit=crop',
    collections: ['soaps'],
    scientificReferences: [
      'Khoa học Đất sét & Đánh giá Khoáng vật học, Tập 18',
      'Tạp chí Da liễu Thẩm mỹ & Lâm sàng Hàng quý, trang 202-211'
    ]
  },
  {
    id: 'rosehip',
    name: 'Dầu hạt tầm xuân hoang dã',
    botanicalName: 'Rosa Canina',
    poeticIntro: 'Mật ngọt hổ phách được ép lạnh từ quả tầm xuân vùng núi cao khắc nghiệt, dồi dào pro-vitamin A và các axit béo omega tái tạo da.',
    originText: 'Được thu hoạch thủ công tại các chân núi hoang dã sau đợt sương giá đầu tiên của mùa thu, khi quả tầm xuân co lại nhẹ và cô đặc lượng lipid hoạt tính sinh học cao nhất.',
    originImage: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?q=80&w=800&auto=format&fit=crop',
    benefits: [
      'Hỗ trợ phân chia tế bào khỏe mạnh và đẩy nhanh tốc độ tái tạo da',
      'Hỗ trợ làm mờ đốm nâu, tổn thương do nắng và các vết sẹo nhỏ',
      'Bổ sung trực tiếp lượng axit béo đậm đặc (linoleic và linolenic)'
    ],
    image: 'https://images.unsplash.com/photo-1496062031256-47a19c721367?q=80&w=800&auto=format&fit=crop',
    collections: ['soaps'],
    scientificReferences: [
      'Tạp chí Khoa học Lipid Châu Âu & Phục hồi Da, 2024',
      'Nghiên cứu Lipid Thảo mộc & Hoa học, Tập 9'
    ]
  }
];

export const journalArticles: JournalArticle[] = [
  {
    id: 'botanical-healing',
    category: 'Nghi thức',
    title: 'Ngôn ngữ của Thảo dược chữa lành: Vẻ đẹp Chậm giữa Thế giới Nhanh',
    excerpt: 'Vì sao việc chuyển đổi thói quen chăm sóc da hàng ngày thành những nghi thức chậm rãi, tỉnh thức giúp kết nối cơ thể ta với nhịp điệu kiên nhẫn của đất trời.',
    content: 'Chúng ta đang sống trong một kỷ nguyên đòi hỏi tốc độ. Thẩm thấu tức thì, lột da thần tốc, thay đổi chỉ sau một đêm. Nhưng làn da, cũng giống như đất mẹ, không vận hành theo mốc thời gian kỹ thuật số. Nó dựa trên sự thay da theo mùa, sự di chuyển tế bào chậm rãi và quá trình phục hồi hàng rào bảo vệ kiên trì. Việc biến các bước làm sạch mỗi ngày thành một nghi thức chánh niệm, chậm rãi—cảm nhận bánh xà phòng đất nung mát lành, xịt nhẹ làn sương ẩm biển sâu, ấn nhẹ lòng bàn tay chứa dầu dưỡng ấm áp—cho phép tâm trí tĩnh lặng và làn da được thở. Vẻ đẹp đích thực là một hành trình tích lũy, sự bồi đắp dịu dàng của dưỡng chất tự nhiên qua từng tuần, từng tháng.',
    author: 'Evelyn Sterling',
    date: '12 Tháng 7, 2026',
    readTime: '6 phút đọc',
    image: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'marine-bioactives',
    category: 'Thành phần',
    title: 'Hoạt chất Sinh học Biển sâu: Khai thác sức mạnh Cấp ẩm Tế bào của Sinh vật Phù du',
    excerpt: 'Khám phá cách sinh vật phù du siêu vi thích nghi với môi trường áp suất cao, làn nước đóng băng của Bắc Băng Dương để tổng hợp các phức hợp khóa ẩm bảo vệ da.',
    content: 'Sự sống nơi đại dương sâu thẳm đã tồn tại hàng triệu năm qua các điều kiện môi trường khắc nghiệt nhất. Dòng sản phẩm METABI của chúng tôi sử dụng chiết xuất sinh vật phù du thô được thu hoạch từ vùng nước thềm lục địa phía Bắc. Vì những tế bào này phải sinh trưởng trong nhiệt độ đóng băng và biến đổi áp suất khí quyển khổng lồ, chúng tự tổng hợp nên các protein bảo vệ và màng polysaccharide dày đặc độc nhất. Khi thoa lên da người, những hoạt chất sinh học này mô phỏng cơ chế bảo vệ tự nhiên của chúng—tạo ra một lớp màng siêu mỏng, thoáng khí giúp ngăn chặn sự mất nước qua biểu bì và khóa độ ẩm xung quanh ngay lập tức.',
    author: 'TS. Thomas Thorne',
    date: '28 Tháng 6, 2026',
    readTime: '8 phút đọc',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'alchemy-clay',
    category: 'Thủ công',
    title: 'Giả kim thuật của Đất Sét: Vì sao phương pháp phơi nắng truyền thống giữ trọn vẹn dược tính khoáng chất',
    excerpt: 'Các lò sấy công nghiệp làm suy thoái mạng tinh thể nhạy cảm của đất sét núi lửa. Hãy cùng tìm hiểu quy trình phơi nắng truyền thống của chúng tôi trên những ngọn đồi phía Nam.',
    content: 'Hầu hết các loại bùn khoáng và mặt nạ đất sét thương mại đều được sấy khô bằng lò gas công nghiệp khổng lồ. Luồng nhiệt cực lớn và nhanh này hút đi hơi ẩm nhưng cũng đồng thời làm mất đi cấu trúc tinh thể tự nhiên của đất sét, khiến các khoáng chất sắt và silica quý giá trở nên trơ lì vô dụng. Tại Avaphar, đất sét nung của chúng tôi được khai thác thủ công, trải đều trên những tấm đá lớn và phơi hoàn toàn dưới ánh nắng tự nhiên trong suốt mười bốn ngày. Sự bay hơi mặt trời dịu nhẹ này bảo tồn điện tích âm phân tử của đất sét—đảm bảo nó hoạt động như một nam châm hút sạch kim loại nặng và tạp chất tích tụ trên da bạn.',
    author: 'Liam Mercer',
    date: '15 Tháng 5, 2026',
    readTime: '5 phút đọc',
    image: 'https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=800&auto=format&fit=crop'
  }
];

export const brandValues = [
  {
    name: 'Chân thật từ Đất đến Da',
    description: 'Chúng tôi truy xuất nguồn gốc của từng bông hoa, thỏi đất sét và giọt biển sâu trở lại chính xác nguồn đất trồng hoặc vùng bờ biển nguyên bản.'
  },
  {
    name: 'Tinh khiết Lọc ba lớp',
    description: 'Kết hợp giữa lên men truyền thống với chiết xuất màng lọc siêu mịn để thu được các lipid đậm đặc mà không cần sử dụng dung môi hóa học.'
  },
  {
    name: 'Phơi nắng Mặt trời Chậm rãi',
    description: 'Đất sét và xà phòng của chúng tôi được phơi khô dịu nhẹ dưới ánh nắng mặt trời ấm áp để giữ nguyên điện tích enzym hoạt động mạnh mẽ.'
  },
  {
    name: 'Thủy tinh Tuần hoàn Vĩnh cửu',
    description: 'Mọi công thức đều được đóng gói trong chai thủy tinh dày lọc ánh sáng màu hổ phách hoặc xám khoáng, có khả năng tái chế vô hạn hoàn toàn.'
  }
];
